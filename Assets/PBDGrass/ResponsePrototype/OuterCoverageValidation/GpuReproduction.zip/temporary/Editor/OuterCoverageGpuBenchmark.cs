using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using GrassFinal.PBDGrass;
using Object=UnityEngine.Object;
public static class OuterCoverageGpuBenchmark
{
    [Serializable] public sealed class Row { public int phase,frame; public double advanceGpuMs,outerBuildMs,coreCullMs,renderMs,outerDrawMs,cpuOuterMs; }
    [Serializable] public sealed class Phase
    {
        public string name; public int samples,minActive=int.MaxValue,maxActive;
        public double advanceGpuMean,outerBuildMean,outerBuildP95,coreCullMean,renderMean,renderP95,outerDrawMean,outerDrawP95,cpuOuterMean;
    }
    [Serializable] public sealed class Report
    {
        public bool passed; public string gpu,error; public int width=1280,height=720,dropped,failed;
        public List<Phase> phases=new List<Phase>(); public List<Row> rows=new List<Row>();
    }
    private struct Info { public int phase,local; public double cpu; }
    private static readonly Dictionary<int,Info> frames=new Dictionary<int,Info>();
    private static readonly string[] names={"overhead_core","overhead_outer","ground_core","ground_outer"};
    private static Report report; private static GrassHandoffDemo demo; private static GrassOuterCoverage outer;
    private static Camera observer; private static UnityEngine.Rendering.CommandBuffer commands;
    private static RenderTexture rt; private static int phase,local,frame,received,flush;
    private const int Warm=60,Count=180;
    public static void Run()
    {
        report=new Report { gpu=SystemInfo.graphicsDeviceName };
        try { PlasticGpuHooks.Function=PlasticGpuHooks.GetRenderEventFunc(); PlasticGpuHooks.Active=true; Next(); EditorApplication.update+=Update; }
        catch(Exception e) { Finish(e); }
    }
    private static void Next()
    {
        if(observer!=null)Object.DestroyImmediate(observer.gameObject); commands?.Dispose();
        if(outer!=null)Object.DestroyImmediate(outer); demo?.Renderer?.Dispose();
        if(rt!=null) { demo.Cam.targetTexture=null; rt.Release(); Object.DestroyImmediate(rt); }
        EditorSceneManager.OpenScene("Assets/PBDGrass/Scenes/PBDGrassOuterCoverage.unity");
        demo=Object.FindObjectOfType<GrassHandoffDemo>(); outer=demo.OuterCoverage;
        demo.enabled=false; outer.enabled=false; demo.Cam.enabled=false; demo.Handoff.DebugLodBaseColors=false;
        rt=new RenderTexture(1280,720,24); rt.Create(); demo.Cam.targetTexture=rt; demo.Cam.aspect=1280f/720;
        demo.OverheadView=phase<2; demo.ConfigureViewCamera();
        if(phase>=2) { demo.Cam.orthographic=false; demo.Cam.transform.position=demo.TourPosition(0); demo.Cam.transform.LookAt(Vector3.up*.6f); }
        demo.Initialize(); outer.Initialize();
        observer=new GameObject("Outer GPU timestamp observer").AddComponent<Camera>(); observer.CopyFrom(demo.Cam); observer.enabled=false;
        observer.transform.SetPositionAndRotation(demo.Cam.transform.position,demo.Cam.transform.rotation);
        commands=new UnityEngine.Rendering.CommandBuffer { name="Outer draw timestamp scope" }; observer.AddCommandBuffer(UnityEngine.Rendering.CameraEvent.AfterForwardOpaque,commands);
        local=0; flush=0;
        report.phases.Add(new Phase { name=names[phase] }); Debug.Log("OUTER_GPU_PHASE "+names[phase]);
    }
    private static void Update()
    {
        try
        {
            while(PlasticGpuHooks.TryPop(out var value)!=0)
            {
                received=Math.Max(received,value.frame);
                if(!frames.TryGetValue(value.frame,out var info) || info.local<Warm)continue;
                report.rows.Add(new Row { phase=info.phase,frame=value.frame,cpuOuterMs=info.cpu,
                    advanceGpuMs=value.ms[1],outerBuildMs=value.ms[2]-value.ms[1],coreCullMs=value.ms[3]-value.ms[2],renderMs=value.ms[4]-value.ms[3],outerDrawMs=value.ms[12]-value.ms[11] });
            }
            if(local==Warm+Count)
            {
                PlasticGpuHooks.Event(31); demo.Cam.Render();
                if(received<frame) { if(++flush>1000)throw new Exception("GPU timestamps did not drain."); return; }
                if(++phase==4) { Finish(null); return; } Next(); return;
            }
            if(frame-received>=32) { PlasticGpuHooks.Event(31); demo.Cam.Render(); return; }
            float time=Mathf.Max(0,local-Warm)/60f; Vector3 focus=demo.TourPosition(time); focus.y=0;
            demo.SimulationFocus.position=focus; demo.Renderer.SimulationCenter=focus;
            demo.Interaction.position=focus+Vector3.forward*1.1f+Vector3.up*.6f;
            demo.Renderer.SetWind(GrassResponseDemo.WindAt(demo.Renderer.SimulationTime,true)*(demo.Wind.magnitude/6),.1f,new Vector4(.01f,.01f,0,1));
            ++frame; PlasticGpuHooks.Event(frame<<6); demo.Renderer.Advance(1f/60); PlasticGpuHooks.Event(1);
            var watch=System.Diagnostics.Stopwatch.StartNew();
            if(phase%2==1)outer.PrepareVisible(); else demo.Renderer.SetOuterCoverage(Vector4.zero);
            watch.Stop(); PlasticGpuHooks.Event(2);
            demo.Renderer.Draw(demo.Cam); if(phase%2==1)outer.RenderPrepared(demo.Cam);
            PlasticGpuHooks.Event(3); demo.Cam.Render(); PlasticGpuHooks.Event(4);
            commands.Clear(); commands.IssuePluginEvent(PlasticGpuHooks.Function,11);
            if(phase%2==1)
            {
                var field=typeof(GrassOuterCoverage).GetField("material",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic);
                commands.DrawProceduralIndirect(Matrix4x4.identity,(Material)field.GetValue(outer),0,MeshTopology.Triangles,outer.DiagnosticArguments,0);
            }
            commands.IssuePluginEvent(PlasticGpuHooks.Function,12); observer.Render(); PlasticGpuHooks.Event(9);
            frames[frame]=new Info { phase=phase,local=local,cpu=watch.Elapsed.TotalMilliseconds };
            int active=demo.Renderer.ActiveBladeCount; var stats=report.phases[phase]; stats.minActive=Math.Min(stats.minActive,active);stats.maxActive=Math.Max(stats.maxActive,active);
            if(active!=32768)throw new Exception("XPBD population changed."); local++;
        }
        catch(Exception e) { Finish(e); }
    }
    private static double P95(IEnumerable<double> values) { var a=values.OrderBy(v=>v).ToArray();return a[(int)Math.Ceiling(a.Length*.95)-1]; }
    private static void Finish(Exception error)
    {
        EditorApplication.update-=Update; PlasticGpuHooks.Active=false;
        if(error!=null)report.error=error.ToString();
        else
        {
            report.dropped=PlasticGpuHooks.GetDropped(); report.failed=PlasticGpuHooks.GetFailed();
            for(int p=0;p<4;p++)
            {
                var rows=report.rows.Where(r=>r.phase==p).ToArray(); var stats=report.phases[p]; stats.samples=rows.Length;
                stats.advanceGpuMean=rows.Average(r=>r.advanceGpuMs); stats.outerBuildMean=rows.Average(r=>r.outerBuildMs); stats.outerBuildP95=P95(rows.Select(r=>r.outerBuildMs));
                stats.coreCullMean=rows.Average(r=>r.coreCullMs); stats.renderMean=rows.Average(r=>r.renderMs); stats.renderP95=P95(rows.Select(r=>r.renderMs));stats.outerDrawMean=rows.Average(r=>r.outerDrawMs);stats.outerDrawP95=P95(rows.Select(r=>r.outerDrawMs));stats.cpuOuterMean=rows.Average(r=>r.cpuOuterMs);
            }
            report.passed=report.rows.Count==Count*4 && report.dropped==0 && report.failed==0;
        }
        File.WriteAllText(Path.Combine(Path.GetTempPath(),"codex-outer-gpu.json"),JsonUtility.ToJson(report,true));
        Debug.Log("OUTER_GPU_DONE "+report.passed+" "+report.error);
        if(observer!=null)Object.DestroyImmediate(observer.gameObject);commands?.Dispose();
        if(outer!=null)Object.DestroyImmediate(outer);demo?.Renderer?.Dispose();
        if(rt!=null) {demo.Cam.targetTexture=null;rt.Release();Object.DestroyImmediate(rt);}
        EditorApplication.Exit(report.passed?0:1);
    }
}
