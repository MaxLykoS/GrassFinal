Run only in an independent copy of the Unity project. Never replace the production renderer.
Copy temporary files to Assets/PBDGrass at their relative paths. Copy native/x86_64/GrassGpuTimer.dll to Assets/Plugins/x86_64.
Open the delivered PBDGrassCombinedBaseline scene; batch entry CombinedGpuBenchmark.Run.
D3D11 timestamp queries; 1280x720; stationary 120 warm + 300 samples; moving 120 warm + 1440 samples.
The query ring is polled without waiting; cap outstanding query frames to 32. No simulation GetData.
1..2: pool transition GPU interval; 3..4: eight XPBD dispatches including final near geometry; 4..5: baked wind and display update.
6..7: culling submission; 8..10: camera render; 0..9: complete GPU interval.
cpuAdvanceMs is CPU wall time for Advance submission, including pool management and driver calls. Not pure CPU kernel time.
GPU display update includes active-blade display copying/blending and reconstruction, not just middle-grass cost.
Output: %TEMP%/codex-combined-gpu-profile/GpuResults.json. Native headers/source and build command included.
