using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using GrassFinal.PBDGrass;
using Object=UnityEngine.Object;
using Debug=UnityEngine.Debug;
public static class CombinedGpuBenchmark
{
    [Serializable] public sealed class Row
    {
        public int frame,phase;
        public double selectionMs,solveMs,displayMs,cullMs,renderMs,totalGpuMs,cpuAdvanceMs;
    }
    [Serializable] public sealed class Summary
    {
        public string phase; public int samples;
        public double solveMean,solveP95,displayMean,displayP95,selectionMean,cullMean,renderMean,totalGpuMean,cpuAdvanceMean;
    }
    [Serializable] public sealed class Report
    {
        public bool passed; public string error,gpu,api;
        public int generated,active,minActive=Int32.MaxValue,maxActive,bezier,width=1280,height=720,substeps,iterations,dropped,failed;
        public List<Row> rows=new List<Row>(); public List<Summary> summaries=new List<Summary>();
    }
    const int Warm=120,Stationary=420,Moving=1560,Total=Stationary+Moving;
    static Report report; static GrassHandoffDemo demo; static Camera camera; static RenderTexture rt;
    static int frame,flush,receivedFrame; static readonly Dictionary<int,double> cpu=new Dictionary<int,double>();
    static string output;
    public static void Run()
    {
        output=Path.Combine(Path.GetTempPath(),"codex-combined-gpu-profile"); Directory.CreateDirectory(output);
        report=new Report { gpu=SystemInfo.graphicsDeviceName,api=SystemInfo.graphicsDeviceType.ToString() };
        try
        {
            EditorSceneManager.OpenScene("Assets/PBDGrass/Scenes/PBDGrassCombinedBaseline.unity");
            demo=Object.FindObjectOfType<GrassHandoffDemo>(); demo.enabled=false; demo.Initialize(); camera=demo.Cam; camera.enabled=false;
            camera.aspect=1280f/720;
            report.generated=demo.Renderer.BladeCount; report.active=demo.Renderer.ActiveBladeCount; report.bezier=report.generated-report.active;
            report.substeps=demo.Physics.NearSubsteps; report.iterations=demo.Physics.ConstraintIterations;
            rt=new RenderTexture(1280,720,24); rt.Create(); camera.targetTexture=rt;
            PlasticGpuHooks.Function=PlasticGpuHooks.GetRenderEventFunc(); PlasticGpuHooks.Active=true;
            EditorApplication.update+=Update;
        }
        catch(Exception e) { Finish(e); }
    }
    static void Update()
    {
        try
        {
            while(PlasticGpuHooks.TryPop(out var value)!=0)
            {
                receivedFrame=Math.Max(receivedFrame,value.frame);
                int i=value.frame-1,phase=i<Stationary?0:1,local=phase==0?i:i-Stationary;
                if(i<0 || i>=Total || local<Warm)continue;
                foreach(int marker in new[] { 0,1,2,3,4,5,6,7,8,9,10 })
                    if(value.ms[marker]<0)throw new Exception("Missing marker "+marker);
                report.rows.Add(new Row { frame=value.frame,phase=phase,selectionMs=value.ms[2]-value.ms[1],
                    solveMs=value.ms[4]-value.ms[3],displayMs=value.ms[5]-value.ms[4],
                    cullMs=value.ms[7]-value.ms[6],renderMs=value.ms[10]-value.ms[8],
                    totalGpuMs=value.ms[9]-value.ms[0],cpuAdvanceMs=cpu[value.frame] });
            }
            if(frame>=Total)
            { PlasticGpuHooks.Event(31); camera.Render(); if(report.rows.Count==1740 || ++flush>300)Finish(null); return; }
            // Do not outrun the native timestamp ring when the editor submits faster than
            // the GPU. Poll later without waiting on a query or reading simulation buffers.
            if(frame-receivedFrame>=32) { PlasticGpuHooks.Event(31); camera.Render(); return; }
            int phaseIndex=frame<Stationary?0:1,phaseFrame=phaseIndex==0?frame:frame-Stationary;
            if(phaseFrame==0) { demo.Renderer.ResetDeformation(); Debug.Log("COMBINED_GPU_PHASE "+phaseIndex); }
            float time=phaseIndex==0?0:Mathf.Max(0,phaseFrame-Warm)/60f;
            camera.transform.position=demo.TourPosition(time); camera.transform.LookAt(Vector3.up*.6f);
            Vector3 focus=camera.transform.position; focus.y=0;
            Vector3 forward=Vector3.ProjectOnPlane(camera.transform.forward,Vector3.up).normalized;
            demo.Interaction.position=focus+forward*1.1f+Vector3.up*.6f;
            demo.Renderer.SimulationCenter=focus;
            demo.Renderer.SetWind(GrassResponseDemo.WindAt(demo.Renderer.SimulationTime,true)*(demo.Wind.magnitude/6),.1f,new Vector4(.01f,.01f,0,1));
            ++frame; PlasticGpuHooks.Event(frame<<6);
            var watch=Stopwatch.StartNew(); demo.Renderer.Advance(1f/60); watch.Stop(); cpu[frame]=watch.Elapsed.TotalMilliseconds;
            int active=demo.Renderer.ActiveBladeCount; report.minActive=Math.Min(report.minActive,active); report.maxActive=Math.Max(report.maxActive,active);
            if(active!=32768)throw new Exception("Lost full XPBD workload");
            demo.Renderer.Draw(camera); PlasticGpuHooks.Event(8); camera.Render(); PlasticGpuHooks.Event(10); PlasticGpuHooks.Event(9);
        }
        catch(Exception e) { Finish(e); }
    }
    static double P95(IEnumerable<double> source)
    { var sorted=source.OrderBy(v=>v).ToArray(); return sorted[(int)Math.Ceiling(sorted.Length*.95)-1]; }
    static void Finish(Exception error)
    {
        EditorApplication.update-=Update; PlasticGpuHooks.Active=false;
        if(error!=null)report.error=error.ToString();
        else
        {
            report.dropped=PlasticGpuHooks.GetDropped(); report.failed=PlasticGpuHooks.GetFailed();
            for(int phase=0;phase<2;phase++)
            {
                var rows=report.rows.Where(r=>r.phase==phase).ToArray();
                if(rows.Length==0)continue;
                report.summaries.Add(new Summary { phase=phase==0?"stationary":"moving_24s",samples=rows.Length,
                    solveMean=rows.Average(r=>r.solveMs),solveP95=P95(rows.Select(r=>r.solveMs)),
                    displayMean=rows.Average(r=>r.displayMs),displayP95=P95(rows.Select(r=>r.displayMs)),
                    selectionMean=rows.Average(r=>r.selectionMs),cullMean=rows.Average(r=>r.cullMs),
                    renderMean=rows.Average(r=>r.renderMs),totalGpuMean=rows.Average(r=>r.totalGpuMs),cpuAdvanceMean=rows.Average(r=>r.cpuAdvanceMs) });
            }
            report.passed=report.generated==131072 && report.minActive==32768 && report.maxActive==32768
                && report.rows.Count==1740 && report.dropped==0 && report.failed==0;
        }
        File.WriteAllText(Path.Combine(output,"GpuResults.json"),JsonUtility.ToJson(report,true));
        Debug.Log("COMBINED_GPU_DONE "+report.passed+" "+report.error);
        if(demo!=null)demo.Renderer?.Dispose();
        if(rt!=null) { camera.targetTexture=null; rt.Release(); Object.DestroyImmediate(rt); }
        EditorApplication.Exit(report.passed?0:1);
    }
}
