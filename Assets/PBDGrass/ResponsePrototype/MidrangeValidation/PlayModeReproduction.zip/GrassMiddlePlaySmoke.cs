using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using GrassFinal.PBDGrass;
using Object=UnityEngine.Object;
[InitializeOnLoad]
public static class GrassMiddlePlaySmoke
{
    private const string Key="CodexGrassMiddlePlaySmoke";
    [Serializable] private sealed class Report
    {
        public bool passed,overheadWorked,returnedToGround;public string error;
        public int minActive=int.MaxValue,maxActive,shifts,ticks,observedFrames;
        public float startX,endX,lastGroundHeight,droppedTime;
    }
    private static GrassHandoffDemo demo;private static Report report;private static double start;private static bool top,ground;
    static GrassMiddlePlaySmoke()
    {
        if(SessionState.GetInt(Key,0)>0)
        {EditorApplication.playModeStateChanged+=State;EditorApplication.update+=Update;}
    }
    public static void Run()
    {
        EditorSceneManager.OpenScene("Assets/PBDGrass/Scenes/PBDGrassMidrange.unity");
        SessionState.SetInt(Key,1);EditorApplication.update-=Update;EditorApplication.update+=Update;EditorApplication.playModeStateChanged-=State;EditorApplication.playModeStateChanged+=State;
        EditorApplication.EnterPlaymode();
    }
    private static void State(PlayModeStateChange value)
    {
        if(value==PlayModeStateChange.EnteredPlayMode)
        {
            demo=Object.FindObjectOfType<GrassHandoffDemo>();report=new Report();report.startX=demo.Cam.transform.position.x;
            demo.AutoTour=true;start=EditorApplication.timeSinceStartup;
        }
        if(value==PlayModeStateChange.EnteredEditMode && SessionState.GetInt(Key,0)==2)
        {
            bool passed=SessionState.GetBool(Key+"Passed",false);SessionState.SetInt(Key,0);EditorApplication.update-=Update;EditorApplication.playModeStateChanged-=State;EditorApplication.Exit(passed?0:1);
        }
    }
    private static void Update()
    {
        if(!EditorApplication.isPlaying || report==null || demo==null || demo.Renderer==null)return;
        try
        {
            double elapsed=EditorApplication.timeSinceStartup-start;report.observedFrames++;
            report.minActive=Math.Min(report.minActive,demo.Renderer.ActiveBladeCount);report.maxActive=Math.Max(report.maxActive,demo.Renderer.ActiveBladeCount);
            if(elapsed>3 && !top) {demo.OverheadView=true;top=true;}
            if(elapsed>3.5 && demo.Cam.orthographic && demo.Cam.transform.position.y>170)report.overheadWorked=true;
            if(elapsed>4.5 && !ground) {demo.OverheadView=false;ground=true;}
            if(elapsed>5.5) {report.lastGroundHeight=demo.Cam.transform.position.y;if(!demo.Cam.orthographic && Mathf.Abs(report.lastGroundHeight-2.5f)<.01f)report.returnedToGround=true;}
            if(elapsed<8)return;
            report.endX=demo.Cam.transform.position.x;report.shifts=demo.WorldLayout.Version;report.ticks=demo.Renderer.SimulationTicks;report.droppedTime=demo.Renderer.DroppedTime;
            report.passed=report.minActive==32768 && report.maxActive==32768 && report.shifts>=4 && report.endX-report.startX>35 && report.overheadWorked && report.returnedToGround;
            if(!report.passed)report.error="Play-mode automatic streaming or view toggle failed.";Finish();
        }
        catch(Exception e) {report.error=e.ToString();Finish();}
    }
    private static void Finish()
    {
        File.WriteAllText(Path.Combine(Path.GetTempPath(),"codex-middle-play.json"),JsonUtility.ToJson(report,true));
        Debug.Log("STREAM_PLAY_SMOKE "+report.passed+" "+report.error);SessionState.SetBool(Key+"Passed",report.passed);SessionState.SetInt(Key,2);report=null;EditorApplication.ExitPlaymode();
    }
}
