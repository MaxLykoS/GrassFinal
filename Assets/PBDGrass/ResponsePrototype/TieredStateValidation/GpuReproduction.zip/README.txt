Use an independent copy of the delivered project. Never install the instrumented renderer in production.
Copy temporary files into Assets/PBDGrass at matching relative paths; native/x86_64 DLL into Assets/Plugins/x86_64.
Run batch method TieredGpuBenchmark.Run with -force-d3d11. Output: %TEMP%/codex-tiered-gpu-profile/GpuResults.json.
1280x720; baseline/tiered stationary (120 warm + 300 samples each), then baseline/tiered moving 24 s (120 warm + 1440 samples each).
32768 active XPBD and 98304 nonphysical blades throughout every phase. Debug base colors disabled in both.
Markers 1..2: selection GPU capture/seed interval; 3..4: all eight XPBD steps and near geometry; 4..5: wind/display interval.
Markers 6..7: culling; 8..10: camera render; 0..9: full GPU interval. CPU Advance includes management/upload/driver wall time.
Native queries poll DONOTFLUSH; cap outstanding frames to 32; no simulation GetData. Native headers/source/build command included.
Original baseline geometry is rebuilt in the display stage; tiered stable near geometry is only built in XPBD. Incoming transitions may still overwrite it.
passed means complete measurement, not the 1ms XPBD target. Other user projects remained running; compare paired phases.
