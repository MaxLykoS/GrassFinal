using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using GrassFinal.PBDGrass;
using Object=UnityEngine.Object;
using Debug=UnityEngine.Debug;
public static class TieredGpuBenchmark
{
    [Serializable] public sealed class Row
    { public int frame,phase; public double selectionMs,solveMs,displayMs,cullMs,renderMs,totalGpuMs,cpuAdvanceMs; }
    [Serializable] public sealed class Summary
    {
        public string name; public int samples,minActive=Int32.MaxValue,maxActive,minHistory=Int32.MaxValue,maxHistory,maxTransition;
        public long allocatedGpuBytes,historyBytes;
        public double solveMean,solveP95,displayMean,displayP95,selectionMean,cullMean,renderMean,totalGpuMean,cpuAdvanceMean;
    }
    [Serializable] public sealed class Report
    {
        public bool passed; public string error,gpu,api; public int generated=131072,width=1280,height=720,substeps=8,iterations=3,dropped,failed;
        public List<Row> rows=new List<Row>(); public List<Summary> phases=new List<Summary>();
    }
    private sealed class FrameInfo { public int phase,local; public double cpu; }
    static Report report; static GrassHandoffDemo demo; static Camera camera; static RenderTexture rt;
    static int frame,local,phase,received,flush; const int Warm=120;
    static readonly Dictionary<int,FrameInfo> frames=new Dictionary<int,FrameInfo>();
    static readonly string[] names={ "baseline_stationary","tiered_stationary","baseline_moving_24s","tiered_moving_24s" };
    static string output;
    public static void Run()
    {
        output=Path.Combine(Path.GetTempPath(),"codex-tiered-gpu-profile"); Directory.CreateDirectory(output);
        report=new Report { gpu=SystemInfo.graphicsDeviceName,api=SystemInfo.graphicsDeviceType.ToString() };
        try
        {
            PlasticGpuHooks.Function=PlasticGpuHooks.GetRenderEventFunc(); PlasticGpuHooks.Active=true;
            NextPhase(); EditorApplication.update+=Update;
        }
        catch(Exception e) { Finish(e); }
    }
    static int SampleCount => phase<2?300:1440;
    static void NextPhase()
    {
        PlasticGpuHooks.Active=false;
        if(demo!=null)demo.Renderer?.Dispose();
        if(rt!=null) { camera.targetTexture=null; rt.Release(); Object.DestroyImmediate(rt); }
        EditorSceneManager.OpenScene("Assets/PBDGrass/Scenes/PBDGrassCombinedBaseline.unity");
        demo=Object.FindObjectOfType<GrassHandoffDemo>(); demo.enabled=false;
        demo.Handoff.UseTieredState=phase%2==1; demo.Handoff.DebugLodBaseColors=false; demo.Handoff.MaxHistoryBlades=65536;
        demo.HandoffShader=AssetDatabase.LoadAssetAtPath<ComputeShader>(phase%2==1?
            "Assets/PBDGrass/Shaders/TieredGrassHandoff.compute":"Assets/PBDGrass/Shaders/GrassHandoff.compute");
        demo.Initialize(); camera=demo.Cam; camera.enabled=false; camera.aspect=1280f/720;
        rt=new RenderTexture(1280,720,24); rt.Create(); camera.targetTexture=rt;
        report.phases.Add(new Summary { name=names[phase],allocatedGpuBytes=demo.Renderer.AllocatedGpuBytes,historyBytes=demo.Renderer.Handoff.HistoryBytes });
        local=0; flush=0; PlasticGpuHooks.Active=true; Debug.Log("TIERED_GPU_PHASE "+names[phase]);
    }
    static void Update()
    {
        try
        {
            while(PlasticGpuHooks.TryPop(out var value)!=0)
            {
                received=Math.Max(received,value.frame);
                if(!frames.TryGetValue(value.frame,out var info) || info.local<Warm)continue;
                foreach(int marker in new[] { 0,1,2,3,4,5,6,7,8,9,10 })if(value.ms[marker]<0)throw new Exception("Missing timestamp marker "+marker);
                report.rows.Add(new Row { frame=value.frame,phase=info.phase,cpuAdvanceMs=info.cpu,
                    selectionMs=value.ms[2]-value.ms[1],solveMs=value.ms[4]-value.ms[3],displayMs=value.ms[5]-value.ms[4],
                    cullMs=value.ms[7]-value.ms[6],renderMs=value.ms[10]-value.ms[8],totalGpuMs=value.ms[9]-value.ms[0] });
            }
            if(local>=Warm+SampleCount)
            {
                PlasticGpuHooks.Event(31); camera.Render();
                if(received<frame) { if(++flush>600)throw new Exception("Native query results did not drain."); return; }
                if(++phase==4) { Finish(null); return; }
                NextPhase(); return;
            }
            if(frame-received>=32) { PlasticGpuHooks.Event(31); camera.Render(); return; }
            float time=phase<2?0:Mathf.Max(0,local-Warm)/60f;
            camera.transform.position=demo.TourPosition(time); camera.transform.LookAt(Vector3.up*.6f);
            Vector3 focus=camera.transform.position; focus.y=0;
            demo.Interaction.position=focus+Vector3.ProjectOnPlane(camera.transform.forward,Vector3.up).normalized*1.1f+Vector3.up*.6f;
            demo.Renderer.SimulationCenter=focus;
            demo.Renderer.SetWind(GrassResponseDemo.WindAt(demo.Renderer.SimulationTime,true)*(demo.Wind.magnitude/6),.1f,new Vector4(.01f,.01f,0,1));
            ++frame; PlasticGpuHooks.Event(frame<<6);
            var watch=Stopwatch.StartNew(); demo.Renderer.Advance(1f/60); watch.Stop();
            frames[frame]=new FrameInfo { phase=phase,local=local,cpu=watch.Elapsed.TotalMilliseconds };
            var summary=report.phases[phase]; int active=demo.Renderer.ActiveBladeCount;
            summary.minActive=Math.Min(summary.minActive,active); summary.maxActive=Math.Max(summary.maxActive,active);
            if(local>=Warm)
            {
                summary.minHistory=Math.Min(summary.minHistory,demo.Renderer.Handoff.HistoryResidentBlades);
                summary.maxHistory=Math.Max(summary.maxHistory,demo.Renderer.Handoff.HistoryResidentBlades);
                summary.maxTransition=Math.Max(summary.maxTransition,demo.Renderer.Handoff.TransitionBlades);
            }
            if(active!=32768)throw new Exception("Lost full XPBD workload.");
            demo.Renderer.Draw(camera); PlasticGpuHooks.Event(8); camera.Render(); PlasticGpuHooks.Event(10); PlasticGpuHooks.Event(9);
            local++;
        }
        catch(Exception e) { Finish(e); }
    }
    static double P95(IEnumerable<double> values)
    { var sorted=values.OrderBy(v=>v).ToArray(); return sorted[(int)Math.Ceiling(sorted.Length*.95)-1]; }
    static void Finish(Exception error)
    {
        EditorApplication.update-=Update; PlasticGpuHooks.Active=false;
        if(error!=null)report.error=error.ToString();
        else
        {
            report.dropped=PlasticGpuHooks.GetDropped(); report.failed=PlasticGpuHooks.GetFailed();
            for(int p=0;p<4;p++)
            {
                var values=report.rows.Where(r=>r.phase==p).ToArray(); var summary=report.phases[p]; summary.samples=values.Length;
                if(values.Length==0)continue;
                summary.solveMean=values.Average(r=>r.solveMs); summary.solveP95=P95(values.Select(r=>r.solveMs));
                summary.displayMean=values.Average(r=>r.displayMs); summary.displayP95=P95(values.Select(r=>r.displayMs));
                summary.selectionMean=values.Average(r=>r.selectionMs); summary.cullMean=values.Average(r=>r.cullMs);
                summary.renderMean=values.Average(r=>r.renderMs); summary.totalGpuMean=values.Average(r=>r.totalGpuMs); summary.cpuAdvanceMean=values.Average(r=>r.cpuAdvanceMs);
            }
            report.passed=report.rows.Count==3480 && report.dropped==0 && report.failed==0
                && report.phases.Count==4 && report.phases.All(p=>p.minActive==32768 && p.maxActive==32768);
        }
        File.WriteAllText(Path.Combine(output,"GpuResults.json"),JsonUtility.ToJson(report,true));
        Debug.Log("TIERED_GPU_DONE "+report.passed+" "+report.error);
        if(demo!=null)demo.Renderer?.Dispose();
        if(rt!=null) { camera.targetTexture=null; rt.Release(); Object.DestroyImmediate(rt); }
        EditorApplication.Exit(report.passed?0:1);
    }
}
