using System;
using System.Runtime.InteropServices;
using UnityEngine;
namespace GrassFinal.PBDGrass
{
    public static class PlasticGpuHooks
    {
        [StructLayout(LayoutKind.Sequential)] public struct Result
        { public int frame, flags; [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)] public double[] ms; }
        [DllImport("GrassGpuTimer", CallingConvention = CallingConvention.Cdecl)] public static extern IntPtr GetRenderEventFunc();
        [DllImport("GrassGpuTimer", CallingConvention = CallingConvention.Cdecl)] public static extern int TryPop(out Result result);
        [DllImport("GrassGpuTimer", CallingConvention = CallingConvention.Cdecl)] public static extern int GetDropped();
        [DllImport("GrassGpuTimer", CallingConvention = CallingConvention.Cdecl)] public static extern int GetFailed();
        public static IntPtr Function;
        public static bool Active;
        public static void Event(int marker) { if (Active) GL.IssuePluginEvent(Function, marker); }
    }
}
