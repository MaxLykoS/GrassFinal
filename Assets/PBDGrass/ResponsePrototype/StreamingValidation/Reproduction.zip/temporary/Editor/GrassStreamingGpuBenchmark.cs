using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using GrassFinal.PBDGrass;
using Object=UnityEngine.Object;
public static class GrassStreamingGpuBenchmark
{
    [Serializable] public sealed class Row
    {public int frame,loadedCells;public bool shifted;public double streamGpuMs,advanceGpuMs,outerGpuMs,renderGpuMs,cpuStreamMs,cpuAdvanceMs;}
    [Serializable] public sealed class Report
    {
        public bool passed;public string gpu,error;public int width=1280,height=720,samples,shiftSamples,minActive=int.MaxValue,maxActive,dropped,failed;
        public double shiftedGpuMean,shiftedGpuP95,shiftedGpuMax,shiftedCpuMean,shiftedCpuP95,shiftedCpuMax,advanceGpuMean,outerGpuMean,renderGpuMean;
        public List<Row> rows=new List<Row>();
    }
    private struct Info {public int local,loaded;public bool shifted;public double stream,advance;}
    private static readonly Dictionary<int,Info> infos=new Dictionary<int,Info>();
    private static Report report;private static GrassHandoffDemo demo;private static GrassOuterCoverage outer;private static Transform ground;
    private static RenderTexture rt;private static int local,frame,received,flush;
    private const int Warm=120,Count=720;
    public static void Run()
    {
        report=new Report {gpu=SystemInfo.graphicsDeviceName};
        try
        {
            EditorSceneManager.OpenScene("Assets/PBDGrass/Scenes/PBDGrassStreaming.unity");demo=Object.FindObjectOfType<GrassHandoffDemo>();outer=demo.OuterCoverage;
            var controller=demo.GetComponent<GrassWorldStreamer>();ground=controller.Ground;controller.enabled=false;demo.enabled=false;outer.enabled=false;demo.Cam.enabled=false;demo.Handoff.DebugLodBaseColors=false;
            rt=new RenderTexture(1280,720,24);rt.Create();demo.Cam.targetTexture=rt;demo.Cam.aspect=1280f/720;demo.Cam.transform.rotation=Quaternion.Euler(8,90,0);
            demo.Initialize();outer.Initialize();PlasticGpuHooks.Function=PlasticGpuHooks.GetRenderEventFunc();PlasticGpuHooks.Active=true;EditorApplication.update+=Update;
        }
        catch(Exception e) {Finish(e);}
    }
    private static void Update()
    {
        try
        {
            while(PlasticGpuHooks.TryPop(out var value)!=0)
            {
                received=Math.Max(received,value.frame);if(!infos.TryGetValue(value.frame,out var info)||info.local<Warm)continue;
                report.rows.Add(new Row {frame=value.frame,shifted=info.shifted,loadedCells=info.loaded,cpuStreamMs=info.stream,cpuAdvanceMs=info.advance,
                    streamGpuMs=value.ms[1],advanceGpuMs=value.ms[2]-value.ms[1],outerGpuMs=value.ms[3]-value.ms[2],renderGpuMs=value.ms[5]-value.ms[4]});
            }
            if(local==Warm+Count)
            {
                PlasticGpuHooks.Event(31);demo.Cam.Render();if(received<frame) {if(++flush>1000)throw new Exception("GPU timestamp queries did not drain.");return;}Finish(null);return;
            }
            if(frame-received>=32) {PlasticGpuHooks.Event(31);demo.Cam.Render();return;}
            int travel=Math.Max(0,local-Warm);var p=new Vector3(-12+travel*.5f,2.5f,-2.5f+Mathf.Sin(travel*.02f)*20);demo.Cam.transform.position=p;
            var focus=p;focus.y=0;demo.Interaction.position=focus+Vector3.right*1.1f+Vector3.up*.6f;
            demo.Renderer.SetWind(GrassResponseDemo.WindAt(demo.Renderer.SimulationTime,true)*(demo.Wind.magnitude/6),.1f,new Vector4(.01f,.01f,0,1));
            ++frame;PlasticGpuHooks.Event(frame<<6);var watch=System.Diagnostics.Stopwatch.StartNew();bool shifted=demo.Renderer.StreamTo(focus);watch.Stop();double cpu=watch.Elapsed.TotalMilliseconds;PlasticGpuHooks.Event(1);
            watch.Restart();demo.Renderer.Advance(1f/60);watch.Stop();double advance=watch.Elapsed.TotalMilliseconds;PlasticGpuHooks.Event(2);
            if(ground!=null)ground.position=demo.WorldLayout.Center-Vector3.up*.025f;
            outer.PrepareVisible();PlasticGpuHooks.Event(3);demo.Renderer.Draw(demo.Cam);outer.RenderPrepared(demo.Cam);
            PlasticGpuHooks.Event(4);demo.Cam.Render();PlasticGpuHooks.Event(5);PlasticGpuHooks.Event(9);
            infos[frame]=new Info {local=local,loaded=shifted?demo.WorldLayout.LastLoadedCells:0,shifted=shifted,stream=cpu,advance=advance};
            int active=demo.Renderer.ActiveBladeCount;report.minActive=Math.Min(report.minActive,active);report.maxActive=Math.Max(report.maxActive,active);if(active!=32768)throw new Exception("Full XPBD workload was lost.");local++;
        }
        catch(Exception e) {Finish(e);}
    }
    private static double P95(IEnumerable<double> values) {var a=values.OrderBy(x=>x).ToArray();return a[(int)Math.Ceiling(a.Length*.95)-1];}
    private static void Finish(Exception error)
    {
        EditorApplication.update-=Update;PlasticGpuHooks.Active=false;
        if(error!=null)report.error=error.ToString();
        else
        {
            var shifts=report.rows.Where(r=>r.shifted).ToArray();report.samples=report.rows.Count;report.shiftSamples=shifts.Length;
            report.shiftedGpuMean=shifts.Average(r=>r.streamGpuMs);report.shiftedGpuP95=P95(shifts.Select(r=>r.streamGpuMs));report.shiftedGpuMax=shifts.Max(r=>r.streamGpuMs);
            report.shiftedCpuMean=shifts.Average(r=>r.cpuStreamMs);report.shiftedCpuP95=P95(shifts.Select(r=>r.cpuStreamMs));report.shiftedCpuMax=shifts.Max(r=>r.cpuStreamMs);
            report.advanceGpuMean=report.rows.Average(r=>r.advanceGpuMs);report.outerGpuMean=report.rows.Average(r=>r.outerGpuMs);report.renderGpuMean=report.rows.Average(r=>r.renderGpuMs);
            report.dropped=PlasticGpuHooks.GetDropped();report.failed=PlasticGpuHooks.GetFailed();report.passed=report.samples==Count&&report.shiftSamples>50&&report.dropped==0&&report.failed==0;
        }
        File.WriteAllText(Path.Combine(Path.GetTempPath(),"codex-stream-gpu.json"),JsonUtility.ToJson(report,true));Debug.Log("STREAM_GPU_DONE "+report.passed+" "+report.error);
        if(outer!=null)Object.DestroyImmediate(outer);demo?.Renderer?.Dispose();if(rt!=null) {demo.Cam.targetTexture=null;rt.Release();Object.DestroyImmediate(rt);}EditorApplication.Exit(report.passed?0:1);
    }
}
