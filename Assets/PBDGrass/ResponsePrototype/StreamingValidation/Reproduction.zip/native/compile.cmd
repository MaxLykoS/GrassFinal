@echo off
call "d:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
cl /nologo /utf-8 /O2 /EHsc /std:c++17 /LD "C:\Users\pc\AppData\Local\Temp\codex-grass-gpu-profile\native\GrassGpuTimer.cpp" /Fo"C:\Users\pc\AppData\Local\Temp\codex-grass-gpu-profile\native\GrassGpuTimer.obj" /link /IMPLIB:"C:\Users\pc\AppData\Local\Temp\codex-grass-gpu-profile\native\GrassGpuTimer.lib" /OUT:"C:\Users\pc\AppData\Local\Temp\codex-grass-gpu-profile\project\Assets\PBDGrass\Profiling\x86_64\GrassGpuTimer.dll" d3d11.lib
