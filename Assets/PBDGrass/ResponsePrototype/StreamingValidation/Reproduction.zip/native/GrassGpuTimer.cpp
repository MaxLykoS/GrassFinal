#include <d3d11.h>
#include <stdint.h>
#include <mutex>
#include <deque>
#include "IUnityInterface.h"
#include "IUnityGraphics.h"
#include "IUnityGraphicsD3D11.h"
static IUnityInterfaces* interfaces=nullptr;
static ID3D11Device* device=nullptr;
static ID3D11DeviceContext* context=nullptr;
static const int RING=128,MARKERS=16;
struct Result { int frame,flags; double ms[MARKERS]; };
struct Slot { ID3D11Query* disjoint=nullptr; ID3D11Query* stamp[MARKERS]={}; int frame=0,flags=0,expected=1,completed=0; bool pending=false; };
static Slot slots[RING];static int current=-1;
static std::mutex resultMutex;static std::deque<Result> results;
static int dropped=0,failed=0;
static bool EnsureDevice()
{
 if(context)return true;
 auto graphics=interfaces?interfaces->Get<IUnityGraphicsD3D11>():nullptr;
 if(!graphics)return false;
 device=graphics->GetDevice();if(!device)return false;
 device->AddRef();device->GetImmediateContext(&context);return context!=nullptr;
}
static bool CreateQueries(Slot& s)
{
 if(s.disjoint)return true;
 D3D11_QUERY_DESC desc={D3D11_QUERY_TIMESTAMP_DISJOINT,0};
 if(FAILED(device->CreateQuery(&desc,&s.disjoint)))return false;
 desc.Query=D3D11_QUERY_TIMESTAMP;
 for(int i=0;i<MARKERS;i++)if(FAILED(device->CreateQuery(&desc,&s.stamp[i])))return false;
 return true;
}
static void Poll()
{
 for(auto& s:slots)
 {
  if(!s.pending)continue;
  D3D11_QUERY_DATA_TIMESTAMP_DISJOINT data={};
  // One nonblocking check, never spin, flush or wait for the GPU.
  if(context->GetData(s.disjoint,&data,sizeof(data),D3D11_ASYNC_GETDATA_DONOTFLUSH)!=S_OK)continue;
  if(data.Disjoint || data.Frequency==0){s.pending=false;dropped++;continue;}
  UINT64 stamps[MARKERS]={};bool ready=true;
  for(int i=0;i<MARKERS;i++)if(s.flags&(1<<i))
   if(context->GetData(s.stamp[i],&stamps[i],sizeof(UINT64),D3D11_ASYNC_GETDATA_DONOTFLUSH)!=S_OK)ready=false;
  if(!ready)continue;
  Result r;r.frame=s.frame;r.flags=s.flags;
  for(int i=0;i<MARKERS;i++)r.ms[i]=(s.flags&(1<<i))?double(stamps[i]-stamps[0])*1000.0/double(data.Frequency):-1;
  {std::lock_guard<std::mutex> lock(resultMutex);results.push_back(r);}
  s.pending=false;
 }
}
static void UNITY_INTERFACE_API RenderEvent(int event)
{
 if(!EnsureDevice()){failed++;return;}
 int marker=event&31;
 if(marker==31){Poll();return;}
 if(marker==0)
 {
  Poll();int frame=event>>6;current=frame%RING;auto& s=slots[current];
  if(s.pending){dropped++;current=-1;return;}
  if(!CreateQueries(s)){failed++;current=-1;return;}
  s.frame=frame;s.flags=0;s.completed=0;s.expected=(event&32)?2:1;
  context->Begin(s.disjoint);
 }
 if(current<0)return;
 auto& s=slots[current];
 if(marker==9 && ++s.completed<s.expected)return;
 context->End(s.stamp[marker]);s.flags|=(1<<marker);
 if(marker==9){context->End(s.disjoint);s.pending=true;current=-1;}
}
extern "C" void UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API UnityPluginLoad(IUnityInterfaces* value){interfaces=value;}
extern "C" void UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API UnityPluginUnload()
{
 for(auto& s:slots){for(auto* q:s.stamp)if(q)q->Release();if(s.disjoint)s.disjoint->Release();}
 if(context)context->Release();if(device)device->Release();context=nullptr;device=nullptr;
}
extern "C" __declspec(dllexport) void* __cdecl GetRenderEventFunc(){return (void*)RenderEvent;}
extern "C" __declspec(dllexport) int __cdecl TryPop(Result* out)
{
 std::lock_guard<std::mutex> lock(resultMutex);if(results.empty())return 0;
 *out=results.front();results.pop_front();return 1;
}
extern "C" __declspec(dllexport) int __cdecl GetDropped(){return dropped;}
extern "C" __declspec(dllexport) int __cdecl GetFailed(){return failed;}
