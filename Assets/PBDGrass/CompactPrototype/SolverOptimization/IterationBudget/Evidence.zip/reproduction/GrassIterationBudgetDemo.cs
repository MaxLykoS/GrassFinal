using UnityEngine;

namespace GrassFinal.PBDGrass
{
    // Attached only to the iteration experiment scene. Baked materials retain
    // their original quality; switching changes live XPBD work, not stored state.
    [DefaultExecutionOrder(-300)]
    public sealed class GrassIterationBudgetDemo : MonoBehaviour
    {
        public enum Budget { Reference8x3, Reduced8x1, Balanced4x2, Fast3x1, Minimum2x1 }
        public GrassHandoffDemo Demo;
        public Budget Quality=Budget.Reduced8x1;
        private Budget applied;

        private void OnEnable() => Apply();
        private void Update()
        {
            if(Input.GetKeyDown(KeyCode.F5))Quality=Budget.Reference8x3;
            if(Input.GetKeyDown(KeyCode.F6))Quality=Budget.Reduced8x1;
            if(Input.GetKeyDown(KeyCode.F7))Quality=Budget.Balanced4x2;
            if(Input.GetKeyDown(KeyCode.F8))Quality=Budget.Fast3x1;
            if(Quality!=applied)Apply();
        }
        public void Apply()
        {
            if(Demo==null)return;
            int steps=8,iterations=1;
            switch(Quality)
            {
                case Budget.Reference8x3:iterations=3;break;
                case Budget.Balanced4x2:steps=4;iterations=2;break;
                case Budget.Fast3x1:steps=3;break;
                case Budget.Minimum2x1:steps=2;break;
            }
            Demo.Physics.NearSubsteps=steps;Demo.Physics.ConstraintIterations=iterations;applied=Quality;
        }
        private void OnGUI()
        {
            if(Demo==null)return;
            float left=Mathf.Max(12,Screen.width-454);
            GUI.Box(new Rect(left,12,442,100),GUIContent.none);
            GUI.Label(new Rect(left+12,18,420,22),"ITERATION EXPERIMENT   "+Demo.Physics.NearSubsteps+" substeps x "+Demo.Physics.ConstraintIterations+" iterations");
            GUI.Label(new Rect(left+12,40,420,22),"F5: 8x3 original    F6: 8x1 reduced");
            GUI.Label(new Rect(left+12,62,420,22),"F7: 4x2 balanced    F8: 3x1 fast (larger pose drift)");
            GUI.Label(new Rect(left+12,84,420,22),"Switch keeps state. R resets grass and actor motion.");
        }
    }
}
