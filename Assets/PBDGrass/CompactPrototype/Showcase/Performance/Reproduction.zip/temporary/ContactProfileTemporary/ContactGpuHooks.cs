using System;
using System.Runtime.InteropServices;
using UnityEngine;
namespace GrassFinal.PBDGrass
{
    public static class ContactGpuHooks
    {
        [StructLayout(LayoutKind.Sequential)] public struct Result
        { public int frame, flags; [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)] public double[] ms; }
        [DllImport("GrassGpuTimer", CallingConvention = CallingConvention.Cdecl)] public static extern IntPtr GetRenderEventFunc();
        [DllImport("GrassGpuTimer", CallingConvention = CallingConvention.Cdecl)] public static extern int TryPop(out Result result);
        [DllImport("GrassGpuTimer", CallingConvention = CallingConvention.Cdecl)] public static extern int GetDropped();
        [DllImport("GrassGpuTimer", CallingConvention = CallingConvention.Cdecl)] public static extern int GetFailed();
        public static long Stamp() => System.Diagnostics.Stopwatch.GetTimestamp();
        public static double Ms(long start) => (Stamp()-start)*1000.0/System.Diagnostics.Stopwatch.Frequency;
        public static double PoolCpu,HandoffCpu,SelectionCpu;
        public static int SelectCalls;
        public static void ResetCpu() {PoolCpu=HandoffCpu=SelectionCpu=0;SelectCalls=0;}
        public static IntPtr Function;
        public static bool Active;
        public static void Event(int marker) { if (Active) GL.IssuePluginEvent(Function, marker); }
    }
}
