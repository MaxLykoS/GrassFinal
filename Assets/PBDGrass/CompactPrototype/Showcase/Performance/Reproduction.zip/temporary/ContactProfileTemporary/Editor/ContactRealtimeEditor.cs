using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
[InitializeOnLoad]
public static class ContactRealtimeEditor
{
    const string Key="ContactRealtimeEditor";
    static ContactRealtimeEditor() {if(SessionState.GetInt(Key,0)>0)Attach();}
    static void Attach()
    {
        EditorApplication.playModeStateChanged-=State;
        EditorApplication.playModeStateChanged+=State;
    }
    public static void Run()
    {
        EditorSceneManager.OpenScene("Assets/PBDGrass/Scenes/PBDGrassContactLab.unity");
        SessionState.SetInt(Key,1);Attach();EditorApplication.EnterPlaymode();
    }
    static void State(PlayModeStateChange state)
    {
        if(state==PlayModeStateChange.EnteredPlayMode)
        {
            ContactRealtimeRunner.Completed=ok => {
                SessionState.SetBool(Key+"Passed",ok);SessionState.SetInt(Key,2);EditorApplication.ExitPlaymode();
            };
            new GameObject("Contact realtime Editor benchmark").AddComponent<ContactRealtimeRunner>();
        }
        if(state==PlayModeStateChange.EnteredEditMode && SessionState.GetInt(Key,0)==2)
        {
            SessionState.SetInt(Key,0);
            EditorApplication.Exit(SessionState.GetBool(Key+"Passed",false)?0:1);
        }
    }
}
