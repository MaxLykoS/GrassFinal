using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using GrassFinal.PBDGrass;
using Object = UnityEngine.Object;
public static class PlasticGpuBenchmark
{
    [Serializable] public sealed class Row { public int frame, phase; public double simulationMs; }
    [Serializable] public sealed class Phase { public string name; public int count; public double mean, p95; }
    [Serializable] public sealed class Report
    {
        public bool passed; public string error, gpu, api; public int generated, active, substeps, iterations, dropped, failed;
        public List<Row> rows = new List<Row>(); public List<Phase> phases = new List<Phase>();
    }
    static Report report; static GrassDemo demo; static Camera camera; static RenderTexture rt;
    static int frame, flush; static string output; static readonly string[] names = { "plastic_off", "plastic_on", "plastic_off_repeat", "plastic_on_repeat" };
    const int Warm = 120, Samples = 300, Frames = Warm + Samples;
    public static void Run()
    {
        report = new Report { gpu = SystemInfo.graphicsDeviceName, api = SystemInfo.graphicsDeviceType.ToString() };
        output = Path.Combine(Path.GetTempPath(), "codex-plastic-profile"); Directory.CreateDirectory(output);
        try
        {
            EditorSceneManager.OpenScene("Assets/PBDGrass/Scenes/PBDGrassDemo.unity");
            demo = Object.FindObjectOfType<GrassDemo>(); demo.enabled = false; demo.Initialize();
            camera = demo.Cam; camera.enabled = false;
            foreach (var depth in Object.FindObjectsOfType<DepthTexMaker>()) depth.enabled = false;
            foreach (var controller in Object.FindObjectsOfType<ColliderController>()) controller.enabled = false;
            foreach (var free in Object.FindObjectsOfType<FreeCam>()) free.enabled = false;
            report.generated = demo.Renderer.BladeCount; report.active = demo.Renderer.ActiveBladeCount;
            report.substeps = demo.Physics.NearSubsteps; report.iterations = demo.Physics.ConstraintIterations;
            rt = new RenderTexture(16, 16, 24); camera.targetTexture = rt;
            PlasticGpuHooks.Function = PlasticGpuHooks.GetRenderEventFunc(); PlasticGpuHooks.Active = true;
            EditorApplication.update += Update;
        }
        catch (Exception e) { Finish(e); }
    }
    static void Update()
    {
        try
        {
            while (PlasticGpuHooks.TryPop(out var value) != 0)
            {
                int i = value.frame - 1;
                if (i < 0 || i >= Frames * 4 || i % Frames < Warm) continue;
                if (value.ms[1] < 0 || value.ms[2] < value.ms[1]) throw new Exception("Invalid timestamp interval");
                report.rows.Add(new Row { frame = value.frame, phase = i / Frames, simulationMs = value.ms[2] - value.ms[1] });
            }
            if (frame >= Frames * 4)
            {
                PlasticGpuHooks.Event(31); camera.Render();
                if (++flush > 120) Finish(null);
                return;
            }
            if (frame % Frames == 0)
            {
                demo.Physics.EnablePlasticity = (frame / Frames) % 2 == 1;
                demo.Renderer.ResetDeformation();
                Debug.Log("PLASTIC_GPU_PHASE " + names[frame / Frames]);
            }
            ++frame; PlasticGpuHooks.Event(frame << 6);
            demo.Renderer.SetWind(demo.WindForce, demo.Frequency, demo.TileAndOffset);
            demo.Renderer.Advance(1f / 60);
            PlasticGpuHooks.Event(9); camera.Render();
        }
        catch (Exception e) { Finish(e); }
    }
    static void Finish(Exception error)
    {
        EditorApplication.update -= Update; PlasticGpuHooks.Active = false;
        if (error == null)
        {
            report.dropped = PlasticGpuHooks.GetDropped(); report.failed = PlasticGpuHooks.GetFailed();
            for (int phase = 0; phase < 4; phase++)
            {
                var values = report.rows.Where(r => r.phase == phase).Select(r => r.simulationMs).OrderBy(v => v).ToArray();
                report.phases.Add(new Phase { name = names[phase], count = values.Length, mean = values.Length > 0 ? values.Average() : -1,
                    p95 = values.Length > 0 ? values[(int)Math.Ceiling(values.Length * .95) - 1] : -1 });
            }
            report.passed = report.generated == 32768 && report.active == 32768 && report.rows.Count == Samples * 4 && report.failed == 0 && report.dropped == 0;
        }
        else report.error = error.ToString();
        File.WriteAllText(Path.Combine(output, "gpu-results.json"), JsonUtility.ToJson(report, true));
        Debug.Log("PLASTIC_GPU_DONE " + report.passed);
        if (demo != null) demo.Renderer?.Dispose();
        EditorApplication.Exit(report.passed ? 0 : 1);
    }
}
