using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using GrassFinal.PBDGrass;
using Object=UnityEngine.Object;
public static class NormalSpaceValidation
{
 [Serializable] class Probe {public int mode;public Color[] before,after;}
 [Serializable] class Result
 {
  public bool passed;public string error;public int blades,triangleSamples;public float oldWindingDot,newWindingDot,bufferChangeAfterCameraRender;
  public int oldOppositeTriangles,newOppositeTriangles,ticksBeforeCameraRender,ticksAfterCameraRender;
  public List<Probe> cameraProbes=new List<Probe>();public int shaderErrors;
 }
 static string output;static Result result=new Result();static GrassDemo demo;static RenderTexture rt;static Texture2D image;
 static void Check(bool ok,string message){if(!ok)throw new Exception(message);}
 static ComputeBuffer GetBuffer(int index)=>( (List<ComputeBuffer>)typeof(PBDGrassPatchRenderer).GetField("buffers",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(demo.Renderer))[index];
 static Vector3[] Read(int index){var buffer=GetBuffer(index);var data=new Vector3[buffer.count];buffer.GetData(data);return data;}
 static void Winding(bool old)
 {
  var positions=Read(6);var normals=Read(7);var indices=demo.Renderer.Data.Triangles;double sum=0;int count=0,opposite=0;
  for(int t=0;t<indices.Length;t+=111){int a=indices[t],b=indices[t+1],c=indices[t+2];var cross=Vector3.Cross(positions[b]-positions[a],positions[c]-positions[a]);if(cross.sqrMagnitude<1e-14f)continue;float dot=Vector3.Dot(cross.normalized,(normals[a]+normals[b]+normals[c]).normalized);sum+=dot;count++;if(dot<0)opposite++;}
  if(old){result.oldWindingDot=(float)(sum/count);result.oldOppositeTriangles=opposite;}
  else{result.newWindingDot=(float)(sum/count);result.newOppositeTriangles=opposite;result.triangleSamples=count;}
 }
 public static void Run()
 {
  output=Path.Combine(Path.GetTempPath(),"codex-grass-normal-space/results");Directory.CreateDirectory(output);
  try
  {
   EditorSceneManager.OpenScene("Assets/PBDGrass/Scenes/PBDGrassDemo.unity");demo=Object.FindObjectOfType<GrassDemo>();demo.enabled=false;
   var solve=demo.PBDSolverCS;demo.PBDSolverCS=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/PBDGrass/Shaders/BeforeNormalSpace.compute");demo.enabled=true;demo.Initialize();Winding(true);
   demo.enabled=false;demo.PBDSolverCS=solve;demo.enabled=true;demo.Initialize();Winding(false);result.blades=demo.Renderer.BladeCount;
   Check(result.blades==32768 && result.oldWindingDot<-.9f && result.newWindingDot>.9f && result.newOppositeTriangles==0,"Reconstructed normals disagree with winding");
   foreach(var depth in Object.FindObjectsOfType<DepthTexMaker>())depth.enabled=false;
   var cam=demo.Cam;cam.enabled=false;cam.aspect=1.5f;var mat=demo.GrassProcedrualMaterial;mat.SetFloat("_DebugView",1);
   rt=new RenderTexture(960,640,24,RenderTextureFormat.DefaultHDR){antiAliasing=4};rt.Create();image=new Texture2D(960,640,TextureFormat.RGB24,false);
   result.ticksBeforeCameraRender=demo.Renderer.SimulationTicks;var raw=Read(7);
   Capture(cam,"raw-main");cam.transform.position=new Vector3(8,4,-8);cam.transform.LookAt(new Vector3(0,.3f,0));Capture(cam,"raw-camera-moved");
   var rawAfter=Read(7);for(int i=0;i<raw.Length;i++)result.bufferChangeAfterCameraRender=Mathf.Max(result.bufferChangeAfterCameraRender,Vector3.Distance(raw[i],rawAfter[i]));
   result.ticksAfterCameraRender=demo.Renderer.SimulationTicks;Check(result.bufferChangeAfterCameraRender==0 && result.ticksBeforeCameraRender==result.ticksAfterCameraRender,"Camera changed normal buffer/physics");
   demo.enabled=false;foreach(var mr in Object.FindObjectsOfType<MeshRenderer>())mr.enabled=false;
   rt.Release();Object.DestroyImmediate(rt);Object.DestroyImmediate(image);rt=new RenderTexture(256,256,24,RenderTextureFormat.ARGBFloat);rt.Create();image=new Texture2D(256,256,TextureFormat.RGBAFloat,false,true);
   Synthetic(cam);
   result.shaderErrors=ShaderUtil.GetShaderMessages(mat.shader).Count(m=>m.severity==UnityEditor.Rendering.ShaderCompilerMessageSeverity.Error);Check(result.shaderErrors==0,"Shader compiler errors");
   result.passed=true;Debug.Log("NORMAL_SPACE_PASS "+JsonUtility.ToJson(result));
  }
  catch(Exception e){result.error=e.ToString();Debug.LogError("NORMAL_SPACE_FAIL "+e);}
  finally{if(demo!=null)demo.enabled=false;if(rt!=null){rt.Release();Object.DestroyImmediate(rt);}if(image!=null)Object.DestroyImmediate(image);File.WriteAllText(Path.Combine(output,"results.json"),JsonUtility.ToJson(result,true));}
  EditorApplication.Exit(result.passed?0:1);
 }
 static void Capture(Camera cam,string name)
 {
  cam.targetTexture=rt;cam.Render();var previous=RenderTexture.active;RenderTexture.active=rt;image.ReadPixels(new Rect(0,0,rt.width,rt.height),0,0);image.Apply();RenderTexture.active=previous;cam.targetTexture=null;
  if(name!=null)File.WriteAllBytes(Path.Combine(output,name+".png"),image.EncodeToPNG());
 }
 static void Synthetic(Camera cam)
 {
  cam.clearFlags=CameraClearFlags.SolidColor;cam.backgroundColor=Color.black;cam.fieldOfView=45;cam.aspect=1;cam.nearClipPlane=.03f;
  var buffers=new List<ComputeBuffer>();Func<Array,int,ComputeBuffer> buffer=(values,stride)=>{var b=new ComputeBuffer(values.Length,stride);b.SetData(values);buffers.Add(b);return b;};
  var positions=new Vector3[15];var normals=new Vector3[15];var uv=new Vector2[15];
  for(int i=0;i<7;i++){positions[i*2]=new Vector3(-1,-1+i*.25f,0);positions[i*2+1]=new Vector3(1,-1+i*.25f,0);}positions[14]=new Vector3(0,1,0);
  for(int i=0;i<15;i++){normals[i]=Vector3.forward;uv[i]=new Vector2(.5f,.5f);}
  var vb=buffer(positions,12);var nb=buffer(normals,12);var tb=buffer(new[]{0,1,14},4);var ub=buffer(uv,8);var gb=buffer(new[]{new GrassGridStruct()},16);var bb=buffer(new[]{new GrassBladeData.Blade{Width=2,Height=2,Length=2,Seed=.5f}},32);
  var shaders=new[]{AssetDatabase.LoadAssetAtPath<Shader>("Assets/PBDGrass/Shaders/BeforeNormalSpace.shader"),demo.GrassProcedrualMaterial.shader};
  var cameras=new[]{new Vector3(-5,0,.5f),new Vector3(5,0,.5f),new Vector3(-5,0,-.5f),new Vector3(5,0,-.5f)};
  try
  {
   foreach(int mode in new[]{1,2,3,4,30})
   {
    var probe=new Probe{mode=mode};var arrays=new Color[2][]; if(mode==30){uv[0]=Vector2.zero;uv[1]=new Vector2(80,0);uv[14]=new Vector2(40,80);ub.SetData(uv);}
    for(int revision=0;revision<2;revision++)
    {
     if(mode==4 && revision==0){arrays[revision]=new Color[0];continue;}
     var mat=new Material(shaders[revision]);mat.SetBuffer("VertexBuffer",vb);mat.SetBuffer("NormalBuffer",nb);mat.SetBuffer("TriangleBuffer",tb);mat.SetBuffer("UvBuffer",ub);mat.SetBuffer("GridsVisibleBuffer",gb);mat.SetBuffer("BladesBuffer",bb);mat.SetFloat("_SpecularAA",mode==30?1:0);if(mode==30)mat.SetFloat("_NormalCurvature",0);mat.SetFloat("_DebugView",mode==30?3:mode);
     var cmd=new CommandBuffer();cmd.DrawProcedural(Matrix4x4.identity,mat,0,MeshTopology.Triangles,3,1);cam.AddCommandBuffer(CameraEvent.BeforeForwardOpaque,cmd);arrays[revision]=new Color[4];
     for(int c=0;c<4;c++){cam.transform.position=cameras[c];cam.transform.LookAt(Vector3.zero);Capture(cam,null);arrays[revision][c]=image.GetPixel(128,128);}
     cam.RemoveCommandBuffer(CameraEvent.BeforeForwardOpaque,cmd);cmd.Release();Object.DestroyImmediate(mat);
    }
    probe.before=arrays[0];probe.after=arrays[1];result.cameraProbes.Add(probe);
    if(mode<4)foreach(var c in probe.after)Check(Mathf.Abs(c.r-.5f)<.003f && Mathf.Abs(c.g-.5f)<.003f && Mathf.Abs(c.b-1)<.003f,"Canonical normal changed with camera: mode "+mode+" "+c);
    else if(mode==30){foreach(var c in probe.after)Check(Mathf.Abs(c.r-probe.after[0].r)<.003f && Mathf.Abs(c.g-probe.after[0].g)<.003f && Mathf.Abs(c.b-probe.after[0].b)<.003f,"Clump hemisphere changed with camera");} else {Check(probe.after[0].b>.99f && probe.after[1].b>.99f && probe.after[2].b<.01f && probe.after[3].b<.01f,"Face orientation does not match triangle front/back");}
   }
  }
  finally{foreach(var b in buffers)b.Release();}
 }
}

