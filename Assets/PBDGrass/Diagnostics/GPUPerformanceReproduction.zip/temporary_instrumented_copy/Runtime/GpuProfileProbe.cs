using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.Rendering;
using Debug=UnityEngine.Debug;
namespace GrassFinal.PBDGrass
{
    public static class PerfHooks
    {
        [StructLayout(LayoutKind.Sequential)] public struct GpuResult
        { public int frame,flags; [MarshalAs(UnmanagedType.ByValArray,SizeConst=16)] public double[] ms; }
        [DllImport("GrassGpuTimer",CallingConvention=CallingConvention.Cdecl)] public static extern IntPtr GetRenderEventFunc();
        [DllImport("GrassGpuTimer",CallingConvention=CallingConvention.Cdecl)] public static extern int TryPop(out GpuResult result);
        [DllImport("GrassGpuTimer",CallingConvention=CallingConvention.Cdecl)] public static extern int GetDropped();
        [DllImport("GrassGpuTimer",CallingConvention=CallingConvention.Cdecl)] public static extern int GetFailed();
        public static bool Active, SkipGrass, Observer;
        public static IntPtr Function;
        public static double CpuSimulationMs,CpuPoolMs,CpuCullMs,CpuHiZMs;
        private static long simStart,poolStart,cullStart,hizStart;
        private static double Milliseconds(long start) => (Stopwatch.GetTimestamp()-start)*1000.0/Stopwatch.Frequency;
        public static void Event(int marker){if(Active)GL.IssuePluginEvent(Function,marker);}
        public static void BeginSimulation(){simStart=Stopwatch.GetTimestamp();}
        public static void EndSimulation(){CpuSimulationMs+=Milliseconds(simStart);}
        public static void BeginPool(){poolStart=Stopwatch.GetTimestamp();}
        public static void EndPool(){CpuPoolMs+=Milliseconds(poolStart);}
        public static void BeginCull(bool observer){cullStart=Stopwatch.GetTimestamp();Event(observer?12:3);}
        public static void EndCull(bool observer){Event(observer?13:4);CpuCullMs+=Milliseconds(cullStart);}
        public static void BeginHiZ(){hizStart=Stopwatch.GetTimestamp();Event(7);}
        public static void EndHiZ(){Event(8);CpuHiZMs+=Milliseconds(hizStart);}
        public static void Reset(){CpuSimulationMs=CpuPoolMs=CpuCullMs=CpuHiZMs=0;}
    }
    [DefaultExecutionOrder(-10000)]
    public sealed class GpuProfileProbe:MonoBehaviour
    {
        [Serializable] public sealed class CpuRow
        {public int frame,phase,ticks;public bool measured;public double simulation,pool,culling,hiz,wallFrame;}
        [Serializable] public sealed class GpuRow
        {public int frame,phase,ticks;public double total,simulation,culling,opaque,hiz,extraOpaque,extraCulling,firstSeven,lastStep;}
        [Serializable] public sealed class Report
        {public string gpu,api,cpu,unity;public int width,height,msaa,generated,active,dropped,failed;
         public int substeps,iterations;public float physicsRate;public int sampleTarget;public string[] phases;
         public List<CpuRow> cpuRows=new List<CpuRow>();public List<GpuRow> gpuRows=new List<GpuRow>();}
        private GrassDemo demo;private Camera observer;private DepthTexMaker depth;private RenderTexture mainTarget,observerTarget;
        private CommandBuffer mainBefore,mainAfter,mainEnd,observerBefore,observerAfter,observerEnd;
        private int phase,phaseFrame,startTicks,lastFrame=-1;private long wallStart;private bool finishing;
        private Dictionary<int,CpuRow> rows=new Dictionary<int,CpuRow>();
        private string output;private Report report;
        private readonly string[] phases={"default_one_tick","no_grass_draw","no_hiz","two_views","default_repeat","realtime_uncapped"};
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] private static void Boot()
        {new GameObject("GPU timestamp performance probe").AddComponent<GpuProfileProbe>();}
        private void Start()
        {
            try
            {
                output=Environment.GetEnvironmentVariable("XPBD_GPU_PROFILE_OUTPUT");if(string.IsNullOrEmpty(output))output=Path.Combine(Application.persistentDataPath,"GpuProfile");
                Directory.CreateDirectory(output);Application.runInBackground=true;Application.targetFrameRate=-1;QualitySettings.vSyncCount=0;
                demo=FindObjectOfType<GrassDemo>();if(demo==null)throw new Exception("Demo missing.");demo.Initialize();
                foreach(var cam in FindObjectsOfType<FreeCam>())cam.enabled=false;
                foreach(var controller in FindObjectsOfType<ColliderController>())controller.enabled=false;
                if(demo.Renderer.BladeCount!=32768 || demo.Renderer.ActiveBladeCount!=32768)throw new Exception("Expected 32768 active blades.");
                PerfHooks.Function=PerfHooks.GetRenderEventFunc();PerfHooks.Active=true;
                depth=demo.Cam.GetComponent<DepthTexMaker>();
                demo.Cam.enabled=false;
                mainTarget=new RenderTexture(1920,1080,24,RenderTextureFormat.DefaultHDR){antiAliasing=QualitySettings.antiAliasing};mainTarget.Create();
                observerTarget=new RenderTexture(1920,1080,24,RenderTextureFormat.DefaultHDR){antiAliasing=QualitySettings.antiAliasing};observerTarget.Create();
                demo.Cam.targetTexture=mainTarget;
                observer=new GameObject("Scene-type observer").AddComponent<Camera>();observer.CopyFrom(demo.Cam);observer.cameraType=CameraType.SceneView;
                observer.targetTexture=observerTarget;observer.depth=demo.Cam.depth+1;observer.transform.position=new Vector3(18,16,-22);observer.transform.LookAt(new Vector3(0,.3f,0));
                mainBefore=Buffer("main opaque begin",5);mainAfter=Buffer("main opaque end",6);mainEnd=Buffer("main complete",14,9);
                demo.Cam.AddCommandBuffer(CameraEvent.BeforeForwardOpaque,mainBefore);demo.Cam.AddCommandBuffer(CameraEvent.AfterForwardOpaque,mainAfter);
                demo.Cam.AddCommandBuffer(CameraEvent.AfterEverything,mainEnd);
                observerBefore=Buffer("observer opaque begin",10);observerAfter=Buffer("observer opaque end",11);observerEnd=Buffer("observer complete",9);
                observer.AddCommandBuffer(CameraEvent.BeforeForwardOpaque,observerBefore);observer.AddCommandBuffer(CameraEvent.AfterForwardOpaque,observerAfter);
                observer.AddCommandBuffer(CameraEvent.AfterEverything,observerEnd);
                report=new Report{gpu=SystemInfo.graphicsDeviceName,api=SystemInfo.graphicsDeviceType.ToString(),cpu=SystemInfo.processorType,
                    unity=Application.unityVersion,width=Screen.width,height=Screen.height,msaa=QualitySettings.antiAliasing,
                    generated=demo.Renderer.BladeCount,active=demo.Renderer.ActiveBladeCount,substeps=demo.Physics.NearSubsteps,
                    iterations=demo.Physics.ConstraintIterations,physicsRate=demo.Physics.SimulationRate,phases=phases,sampleTarget=600};
                ConfigurePhase();wallStart=Stopwatch.GetTimestamp();Debug.Log("GPU_PROFILE_START "+report.gpu+" "+Screen.width+"x"+Screen.height);
            }
            catch(Exception e){Debug.LogError(e);Application.Quit(1);}
        }
        private CommandBuffer Buffer(string name,params int[] markers)
        {var buffer=new CommandBuffer{name=name};foreach(var m in markers)buffer.IssuePluginEvent(PerfHooks.Function,m);return buffer;}
        private void ConfigurePhase()
        {
            PerfHooks.SkipGrass=phase==1;PerfHooks.Observer=phase==3;observer.enabled=false;
            depth.enabled=phase!=2;Time.captureDeltaTime=phase==5?0:1f/60;
            Debug.Log("GPU_PROFILE_PHASE "+phases[phase]);
        }
        private void Update()
        {
            if(report==null)return;
            if(lastFrame>=0 && rows.TryGetValue(lastFrame,out var previous)){previous.hiz=PerfHooks.CpuHiZMs;previous.culling=PerfHooks.CpuCullMs;}
            Drain();
            if(finishing)
            {
                PerfHooks.Event(31);if(++phaseFrame>120){Save();Application.Quit(0);}return;
            }
            int warm=phase==0||phase==5?180:120;int sample=phase==5?900:600;
            if(phaseFrame>=warm+sample)
            {
                phase++;phaseFrame=0;
                if(phase>=phases.Length){finishing=true;observer.enabled=false;PerfHooks.Observer=false;Time.captureDeltaTime=0;return;}
                ConfigurePhase();
            }
            phaseFrame++;lastFrame=Time.frameCount;PerfHooks.Reset();startTicks=demo.Renderer.SimulationTicks;
            var row=new CpuRow{frame=lastFrame,phase=phase,measured=phaseFrame>warm,
                wallFrame=(Stopwatch.GetTimestamp()-wallStart)*1000.0/Stopwatch.Frequency};wallStart=Stopwatch.GetTimestamp();
            rows[lastFrame]=row;report.cpuRows.Add(row);
            PerfHooks.Event((lastFrame<<6)|(PerfHooks.Observer?32:0));
        }
        private void LateUpdate()
        {
            if(report==null||finishing||lastFrame<0)return;var row=rows[lastFrame];
            row.ticks=demo.Renderer.SimulationTicks-startTicks;row.simulation=PerfHooks.CpuSimulationMs;row.pool=PerfHooks.CpuPoolMs;
            if(PerfHooks.Observer)observer.Render();
            demo.Cam.Render();
        }
        private void OnPostRender(){}
        private void Drain()
        {
            while(PerfHooks.TryPop(out var gpu)!=0)
            {
                if(!rows.TryGetValue(gpu.frame,out var row)||!row.measured)continue;
                double[] t=gpu.ms;
                Func<int,int,double> duration=(a,b)=>t[a]>=0&&t[b]>=0?t[b]-t[a]:-1;
                report.gpuRows.Add(new GpuRow{frame=gpu.frame,phase=row.phase,ticks=row.ticks,
                    total=duration(0,9),simulation=duration(1,2),culling=duration(3,4),opaque=duration(5,6),hiz=duration(7,8),
                    extraOpaque=duration(10,11),extraCulling=duration(12,13),firstSeven=duration(1,15),lastStep=duration(15,2)});

            }
        }
        private void Save()
        {
            PerfHooks.Active=false;report.dropped=PerfHooks.GetDropped();report.failed=PerfHooks.GetFailed();
            File.WriteAllText(Path.Combine(output,"gpu-profile-raw.json"),JsonUtility.ToJson(report,true));
            Debug.Log("GPU_PROFILE_FINISHED gpu_samples="+report.gpuRows.Count+" dropped="+report.dropped+" failed="+report.failed);
        }
    }
}
