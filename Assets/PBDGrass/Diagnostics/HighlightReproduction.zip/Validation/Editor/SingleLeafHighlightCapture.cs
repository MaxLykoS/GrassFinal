using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using GrassFinal.PBDGrass;
using Object=UnityEngine.Object;
public static class SingleLeafHighlightCapture
{
 static Camera camera;static Material material;static Bounds bounds=new Bounds(new Vector3(0,.325f,0),Vector3.one*2);static ComputeBuffer args;
 static void Draw(Camera c){if(c==camera)Graphics.DrawProceduralIndirect(material,bounds,MeshTopology.Triangles,args,0,c,null,ShadowCastingMode.Off,false);}
 public static void Run()
 {
  string output=Path.Combine(Path.GetTempPath(),"codex-grass-highlight-audit/single-leaf");Directory.CreateDirectory(output);var buffers=new List<ComputeBuffer>();bool pass=false;
  try
  {
   EditorSceneManager.OpenScene("Assets/PBDGrass/Scenes/PBDGrassDemo.unity");var demo=Object.FindObjectOfType<GrassDemo>();demo.enabled=false;var source=demo.GrassProcedrualMaterial;camera=demo.Cam;camera.enabled=false;camera.aspect=1;
   foreach(var depth in Object.FindObjectsOfType<DepthTexMaker>())depth.enabled=false;foreach(var mr in Object.FindObjectsOfType<MeshRenderer>())mr.enabled=false;
   camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=Color.black;camera.fieldOfView=45;camera.nearClipPlane=.01f;camera.farClipPlane=10;camera.transform.position=new Vector3(0,.325f,-.22f);camera.transform.LookAt(new Vector3(0,.325f,0));
   RenderSettings.fog=false;RenderSettings.ambientLight=Color.black;QualitySettings.shadows=ShadowQuality.Disable;
   var sun=Object.FindObjectsOfType<Light>().First(l=>l.type==LightType.Directional);sun.color=Color.white;sun.intensity=1;
   var pos=new Vector3[15];var normals=new Vector3[15];var uv=new Vector2[15];var tri=new int[39];int ti=0;
   for(int s=0;s<7;s++){float u=s/7f;pos[s*2]=new Vector3(-.015f*(1-u),u*.65f,0);pos[s*2+1]=new Vector3(.015f*(1-u),u*.65f,0);uv[s*2]=new Vector2(0,u);uv[s*2+1]=new Vector2(1,u);}
   pos[14]=new Vector3(0,.65f,0);uv[14]=new Vector2(.5f,1);for(int i=0;i<15;i++)normals[i]=Vector3.back;
   for(int s=1;s<7;s++){tri[ti++]=s*2;tri[ti++]=s*2+1;tri[ti++]=s*2-2;tri[ti++]=s*2+1;tri[ti++]=s*2-1;tri[ti++]=s*2-2;}tri[ti++]=14;tri[ti++]=13;tri[ti++]=12;
   Func<Array,int,ComputeBuffer> buffer=(a,stride)=>{var b=new ComputeBuffer(a.Length,stride);b.SetData(a);buffers.Add(b);return b;};
   var positions=buffer(pos,12);var normal=buffer(normals,12);var triangles=buffer(tri,4);var uvs=buffer(uv,8);var grids=buffer(new[]{new GrassGridStruct()},16);var blades=buffer(new[]{new GrassBladeData.Blade{Width=.03f,Length=.65f,Height=.65f,Seed=.5f}},32);
   args=new ComputeBuffer(4,4,ComputeBufferType.IndirectArguments);args.SetData(new uint[]{39,1,0,0});buffers.Add(args);
   var shaders=new[]{AssetDatabase.LoadAssetAtPath<Shader>("Assets/PBDGrass/Shaders/BeforeHighlight.shader"),source.shader};
   var log="";Camera.onPreCull+=Draw;
   for(int revision=0;revision<2;revision++)
   {
    material=new Material(source);material.shader=shaders[revision];material.SetFloat("_DebugView",5);material.SetBuffer("VertexBuffer",positions);material.SetBuffer("NormalBuffer",normal);material.SetBuffer("TriangleBuffer",triangles);material.SetBuffer("UvBuffer",uvs);material.SetBuffer("GridsVisibleBuffer",grids);material.SetBuffer("BladesBuffer",blades);
    foreach(int angle in new[]{-45,0,45})
    {
     float rad=angle*Mathf.Deg2Rad;Vector3 direction=new Vector3(Mathf.Sin(rad),0,-Mathf.Cos(rad));sun.transform.rotation=Quaternion.LookRotation(-direction);
     var rt=new RenderTexture(512,512,24,RenderTextureFormat.ARGBFloat){antiAliasing=4};rt.Create();camera.targetTexture=rt;camera.Render();var previous=RenderTexture.active;RenderTexture.active=rt;
     var tex=new Texture2D(512,512,TextureFormat.RGBAFloat,false,true);tex.ReadPixels(new Rect(0,0,512,512),0,0);tex.Apply();RenderTexture.active=previous;camera.targetTexture=null;
     var pixels=tex.GetPixels();float max=pixels.Max(c=>c.r);log+=(revision==0?"before":"after")+" angle="+angle+" max="+max+"\n";
     var png=new Texture2D(512,512,TextureFormat.RGB24,false);png.SetPixels(pixels);png.Apply();File.WriteAllBytes(Path.Combine(output,(revision==0?"before":"after")+"-"+angle+".png"),png.EncodeToPNG());
     if(max<=0 || float.IsNaN(max))throw new Exception("Single leaf did not render a highlight");
     rt.Release();Object.DestroyImmediate(rt);Object.DestroyImmediate(tex);Object.DestroyImmediate(png);
    }
    Object.DestroyImmediate(material);
   }
   File.WriteAllText(Path.Combine(output,"results.txt"),log);Debug.Log("SINGLE_LEAF_HIGHLIGHT_PASS\n"+log);pass=true;
  }
  catch(Exception e){Debug.LogError(e);}
  finally{Camera.onPreCull-=Draw;foreach(var buffer in buffers)buffer.Release();if(material!=null)Object.DestroyImmediate(material);}
  EditorApplication.Exit(pass?0:1);
 }
}

