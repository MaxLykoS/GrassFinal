using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using GrassFinal.PBDGrass;
using Object=UnityEngine.Object;
public static class LightingValidation
{
    [Serializable] public class Result
    {
        public bool passed; public string error,gpu,unity; public int generated,active;
        public double oldFront,newFront,oldBack,newBack,noTransmissionBack,darkMax,redLightGreenMax,halfLightMean,fullLightMean,shadowDifference;
        public int shaderErrors; public uint mainVisible,sceneVisible,hiddenVisible;public int simulationTicks;
    }
    static GrassDemo demo;static Camera cam;static Light sun;static string output;static Result result;
    static void Check(bool ok,string message){if(!ok)throw new Exception(message);}
    public static void Run()
    {
        result=new Result{gpu=SystemInfo.graphicsDeviceName,unity=Application.unityVersion};
        output=Path.Combine(Path.GetTempPath(),"codex-grass-highlight-audit/lighting-regression-gamma");Directory.CreateDirectory(output);
        try
        {
            EditorSceneManager.OpenScene("Assets/PBDGrass/Scenes/PBDGrassDemo.unity");
            demo=Object.FindObjectOfType<GrassDemo>();demo.enabled=false;cam=demo.Cam;cam.enabled=false;
            foreach(var d in Object.FindObjectsOfType<DepthTexMaker>())d.enabled=false;
            foreach(var l in Object.FindObjectsOfType<Light>())l.enabled=false;
            sun=new GameObject("Lighting test sun").AddComponent<Light>();sun.type=LightType.Directional;sun.color=new Color(1,.95686f,.83921f);sun.intensity=1;
            RenderSettings.sun=sun;RenderSettings.fog=false;SetAmbient(new Color(.24f,.26f,.30f));
            QualitySettings.antiAliasing=4;QualitySettings.shadows=ShadowQuality.Disable;
            cam.clearFlags=CameraClearFlags.SolidColor;cam.backgroundColor=new Color(.19f,.25f,.31f);cam.farClipPlane=80;
            cam.transform.position=new Vector3(0,1.35f,-5);cam.transform.LookAt(new Vector3(0,.3f,2));cam.fieldOfView=60;cam.aspect=1.5f;
            var original=AssetDatabase.LoadAssetAtPath<Material>("Assets/PBDGrass/Materials/LightingBaseline.mat");
            var upgraded=AssetDatabase.LoadAssetAtPath<Material>("Assets/PBDGrass/Materials/PBDGrassProcedualMaterial.mat");
            Check(original!=null && upgraded!=null,"Materials missing");upgraded.SetFloat("_DebugView",0);
            SetMaterial(upgraded);result.generated=demo.Renderer.BladeCount;result.active=demo.Renderer.ActiveBladeCount;
            Check(result.generated==32768 && result.active==32768,"Expected exactly 32768 active blades");
            sun.transform.rotation=Quaternion.Euler(35,-30,0);
            SetMaterial(original);result.oldFront=Capture("old-front").Average(Luma);
            SetMaterial(upgraded);result.newFront=Capture("new-front").Average(Luma);
            sun.transform.rotation=Quaternion.Euler(25,180,0);
            SetMaterial(original);result.oldBack=Capture("old-back").Average(Luma);
            SetMaterial(upgraded);result.newBack=Capture("new-back").Average(Luma);
            var noTrans=new Material(upgraded);noTrans.SetFloat("_Transmission",0);SetMaterial(noTrans);result.noTransmissionBack=Capture("new-back-no-transmission").Average(Luma);
            SetMaterial(upgraded);Object.DestroyImmediate(noTrans);
            // Visibility continues to use the designated main camera for a Scene camera.
            Capture(null);result.mainVisible=demo.Renderer.VisibleGridCount();
            var scene=new GameObject("Scene lighting probe").AddComponent<Camera>();scene.CopyFrom(cam);scene.enabled=false;scene.cameraType=CameraType.SceneView;
            scene.transform.position=new Vector3(8,5,-8);scene.transform.LookAt(new Vector3(0,.3f,0));
            Capture("new-scene",scene);result.sceneVisible=demo.Renderer.VisibleGridCount();
            var rotation=cam.transform.rotation;var position=cam.transform.position;cam.transform.position=new Vector3(0,5,-22);cam.transform.rotation=Quaternion.LookRotation(Vector3.back);Capture(null,scene);result.hiddenVisible=demo.Renderer.VisibleGridCount();cam.transform.rotation=rotation;cam.transform.position=position;
            result.simulationTicks=demo.Renderer.SimulationTicks;Object.DestroyImmediate(scene.gameObject);
            Check(result.mainVisible==result.sceneVisible && result.hiddenVisible==0 && result.simulationTicks==0,"Scene view changed culling or advanced physics");
            // Isolate the grass for radiometric checks. Readback occurs only in this editor fixture.
            foreach(var mr in Object.FindObjectsOfType<MeshRenderer>())mr.enabled=false;
            cam.backgroundColor=Color.black;SetAmbient(Color.black);sun.color=Color.white;
            sun.intensity=0;result.darkMax=Capture("new-no-light",null,true).Max(c=>(double)Mathf.Max(c.r,Mathf.Max(c.g,c.b)));
            Check(result.darkMax<1e-5,"Unlit grass emitted light");
            sun.intensity=.5f;result.halfLightMean=Capture(null,null,true).Average(Luma);
            sun.intensity=1;result.fullLightMean=Capture(null,null,true).Average(Luma);
            Check(Math.Abs(result.fullLightMean/result.halfLightMean-2)<.03,"Direct light does not scale with light intensity");
            sun.color=Color.red;result.redLightGreenMax=Capture(null,null,true).Max(c=>(double)Mathf.Max(c.g,c.b));
            Check(result.redLightGreenMax<1e-5,"Transmission/specular ignored light color");
            sun.color=Color.white;SetAmbient(new Color(.14f,.16f,.19f));sun.transform.rotation=Quaternion.Euler(35,-30,0);
            QualitySettings.shadows=ShadowQuality.All;QualitySettings.shadowDistance=40;QualitySettings.shadowCascades=2;QualitySettings.shadowResolution=ShadowResolution.High;
            sun.shadows=LightShadows.Soft;sun.shadowBias=.015f;sun.shadowNormalBias=.1f;
            var blocker=GameObject.CreatePrimitive(PrimitiveType.Cube);blocker.transform.position=new Vector3(0,1.25f,.5f);blocker.transform.localScale=new Vector3(3,1,2);
            var mrBlock=blocker.GetComponent<MeshRenderer>();mrBlock.shadowCastingMode=ShadowCastingMode.ShadowsOnly;
            var shadowed=Capture("new-shadow",null,true);sun.shadows=LightShadows.None;var clear=Capture("new-without-shadow",null,true);
            result.shadowDifference=shadowed.Zip(clear,(a,b)=>Math.Abs(Luma(a)-Luma(b))).Average();
            Check(result.shadowDifference>1e-5,"Shadow reception did not affect grass");
            result.shaderErrors=ShaderUtil.GetShaderMessages(upgraded.shader).Count(m=>m.severity==UnityEditor.Rendering.ShaderCompilerMessageSeverity.Error);
            Check(result.shaderErrors==0,"Shader compilation errors");
            Check(result.newBack>result.noTransmissionBack,"Back transmission did not contribute");
            result.passed=true;Debug.Log("LIGHTING_VALIDATION_PASS "+JsonUtility.ToJson(result));
        }
        catch(Exception e){result.error=e.ToString();Debug.LogError("LIGHTING_VALIDATION_FAIL "+e);}
        finally{if(demo!=null)demo.enabled=false;File.WriteAllText(Path.Combine(output,"results.json"),JsonUtility.ToJson(result,true));}
        EditorApplication.Exit(result.passed?0:1);
    }
    static double Luma(Color c){return c.r*.2126+c.g*.7152+c.b*.0722;}
    static void SetAmbient(Color color){RenderSettings.ambientMode=AmbientMode.Flat;RenderSettings.ambientLight=color;RenderSettings.ambientIntensity=1;var sh=new SphericalHarmonicsL2();sh.AddAmbientLight(color);RenderSettings.ambientProbe=sh;}
    static void SetMaterial(Material mat){demo.enabled=false;demo.GrassProcedrualMaterial=mat;demo.enabled=true;demo.Initialize();}
    static Color[] Capture(string name,Camera target=null,bool hdr=false)
    {
        target=target??cam;var rt=new RenderTexture(960,640,24,hdr?RenderTextureFormat.ARGBFloat:RenderTextureFormat.DefaultHDR){antiAliasing=4};rt.Create();
        var image=new Texture2D(960,640,TextureFormat.RGBAFloat,false,true);target.targetTexture=rt;target.Render();
        var prev=RenderTexture.active;RenderTexture.active=rt;image.ReadPixels(new Rect(0,0,960,640),0,0);image.Apply();RenderTexture.active=prev;target.targetTexture=null;
        var pixels=image.GetPixels();
        if(name!=null){var png=new Texture2D(960,640,TextureFormat.RGB24,false);png.SetPixels(pixels);png.Apply();File.WriteAllBytes(Path.Combine(output,name+".png"),png.EncodeToPNG());Object.DestroyImmediate(png);}
        rt.Release();Object.DestroyImmediate(rt);Object.DestroyImmediate(image);return pixels;
    }
}



