using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using GrassFinal.PBDGrass;
using Object=UnityEngine.Object;
public static class HighlightAudit
{
 [Serializable] public class Stat{public string name;public int pixels;public float[] mean,min,max,p95,negativeFraction;}
 [Serializable] public class Report{public string error,colorSpace;public Vector3 camera,light;public List<Stat> stats=new List<Stat>();}
 static GrassDemo demo;static Material material;static Camera cam;static string output;static Report report=new Report();
 public static void Run()
 {
  output=Path.Combine(Path.GetTempPath(),"codex-grass-highlight-audit/results-fixed-gamma");Directory.CreateDirectory(output);
  try
  {
   EditorSceneManager.OpenScene("Assets/PBDGrass/Scenes/PBDGrassDemo.unity");demo=Object.FindObjectOfType<GrassDemo>();demo.Initialize();cam=demo.Cam;cam.enabled=false;cam.aspect=1.5f;
   foreach(var d in Object.FindObjectsOfType<DepthTexMaker>())d.enabled=false;foreach(var mr in Object.FindObjectsOfType<MeshRenderer>())mr.enabled=false;
   cam.clearFlags=CameraClearFlags.SolidColor;cam.backgroundColor=Color.clear;RenderSettings.fog=false;QualitySettings.shadows=ShadowQuality.Disable;
   demo.GrassProcedrualMaterial.SetFloat("_DebugView",5);material=(Material)typeof(PBDGrassPatchRenderer).GetField("material",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(demo.Renderer);
   report.colorSpace=QualitySettings.activeColorSpace.ToString();report.camera=cam.transform.position;report.light=-Object.FindObjectsOfType<Light>().First(l=>l.type==LightType.Directional).transform.forward;
   foreach(string phase in new[]{"rest","wind"})
   {
    if(phase=="wind"){demo.Renderer.SetWind(new Vector3(10,0,3),.1f,new Vector4(.01f,.01f,0,1));for(int i=0;i<60;i++)demo.Renderer.Advance(1f/60);}
    for(int probe=0;probe<=16;probe++){material.SetFloat("_SpecularProbe",probe);Capture(phase+"-probe-"+probe);}
    material.SetFloat("_SpecularProbe",0);material.SetFloat("_SpecularAA",0);Capture(phase+"-no-aa");material.SetFloat("_SpecularAA",1);
   }
   Debug.Log("HIGHLIGHT_AUDIT_PASS");
  }
  catch(Exception e){report.error=e.ToString();Debug.LogError(e);}
  finally{if(demo!=null)demo.enabled=false;File.WriteAllText(Path.Combine(output,"report.json"),JsonUtility.ToJson(report,true));}
  EditorApplication.Exit(string.IsNullOrEmpty(report.error)?0:1);
 }
 static void Capture(string name)
 {
  var rt=new RenderTexture(960,640,24,RenderTextureFormat.ARGBFloat){antiAliasing=4};rt.Create();cam.targetTexture=rt;cam.Render();
  var previous=RenderTexture.active;RenderTexture.active=rt;var tex=new Texture2D(960,640,TextureFormat.RGBAFloat,false,true);tex.ReadPixels(new Rect(0,0,960,640),0,0);tex.Apply();RenderTexture.active=previous;cam.targetTexture=null;
  var pixels=tex.GetPixels().Where(c=>c.a>.999f).ToArray();var stat=new Stat{name=name,pixels=pixels.Length,mean=new float[3],min=new float[3],max=new float[3],p95=new float[3],negativeFraction=new float[3]};
  for(int k=0;k<3;k++){var values=pixels.Select(c=>c[k]).OrderBy(x=>x).ToArray();stat.mean[k]=values.Average();stat.min[k]=values[0];stat.max[k]=values[values.Length-1];stat.p95[k]=values[(int)(values.Length*.95)];stat.negativeFraction[k]=(float)values.Count(v=>v<0)/values.Length;}
  report.stats.Add(stat);Debug.Log(JsonUtility.ToJson(stat));
  if(name.EndsWith("probe-0") || name.EndsWith("probe-5") || name.EndsWith("probe-6") || name.EndsWith("no-aa")){var png=new Texture2D(960,640,TextureFormat.RGB24,false);png.SetPixels(tex.GetPixels());png.Apply();File.WriteAllBytes(Path.Combine(output,name+".png"),png.EncodeToPNG());Object.DestroyImmediate(png);}
  rt.Release();Object.DestroyImmediate(rt);Object.DestroyImmediate(tex);
 }
}

