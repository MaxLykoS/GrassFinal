using System;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using GrassFinal.PBDGrass;
using Object=UnityEngine.Object;
public static class SpecularOnlyCapture
{
 static GrassDemo demo;static string output;
 public static void Run()
 {
  bool pass=false;Material source=null;output=Path.Combine(Path.GetTempPath(),"codex-grass-specular-only");Directory.CreateDirectory(output);
  try
  {
   EditorSceneManager.OpenScene("Assets/PBDGrass/Scenes/PBDGrassDemo.unity");demo=Object.FindObjectOfType<GrassDemo>();demo.Initialize();
   foreach(var depth in Object.FindObjectsOfType<DepthTexMaker>())depth.enabled=false;
   var cam=demo.Cam;cam.enabled=false;cam.aspect=1.5f;source=demo.GrassProcedrualMaterial;
   if(source.GetFloat("_DebugView")!=5)throw new Exception("Demo did not default to specular only");
   demo.Renderer.SetWind(new Vector3(10,0,3),.1f,new Vector4(.01f,.01f,0,1));for(int i=0;i<60;i++)demo.Renderer.Advance(1f/60);
   var renderer=demo.Renderer;int ticks=renderer.SimulationTicks;var specular=Capture(cam,"specular-only");
   source.SetFloat("_DebugView",0);var lit=Capture(cam,"lit");if(specular.Zip(lit,(a,b)=>(double)Mathf.Abs(a.g-b.g)).Average()<1e-5)throw new Exception("Debug mode did not change output");source.SetFloat("_DebugView",5);
   foreach(var mesh in Object.FindObjectsOfType<MeshRenderer>())mesh.enabled=false;cam.clearFlags=CameraClearFlags.SolidColor;cam.backgroundColor=Color.black;
   var isolated=Capture(cam,"specular-only-isolated");float max=isolated.Max(c=>Mathf.Max(c.r,Mathf.Max(c.g,c.b)));if(max<=0)throw new Exception("No specular pixels");
   var material=(Material)typeof(PBDGrassPatchRenderer).GetField("material",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(renderer);material.SetFloat("_SpecularStrength",0);
   var disabled=Capture(cam,null);if(disabled.Any(c=>c.r>1e-6 || c.g>1e-6 || c.b>1e-6))throw new Exception("Non-specular terms leaked into output");
   if(renderer!=demo.Renderer || ticks!=renderer.SimulationTicks)throw new Exception("Debug mode reset/advanced physics");
   if(ShaderUtil.GetShaderMessages(source.shader).Any(m=>m.severity==UnityEditor.Rendering.ShaderCompilerMessageSeverity.Error))throw new Exception("Shader compiler error");
   pass=true;Debug.Log("SPECULAR_ONLY_PASS max="+max+" zero strength is black; debug mode switches live; shader errors=0");
  }
  catch(Exception e){Debug.LogError(e);}
  finally{if(source!=null)source.SetFloat("_DebugView",5);if(demo!=null)demo.enabled=false;File.WriteAllText(Path.Combine(output,"result.txt"),pass?"PASS":"FAIL");}
  if(!pass){EditorApplication.Exit(1);return;} LightingValidation.Run();
 }
 static Color[] Capture(Camera cam,string name)
 {
  var rt=new RenderTexture(960,640,24,RenderTextureFormat.DefaultHDR){antiAliasing=4};rt.Create();cam.targetTexture=rt;cam.Render();
  var previous=RenderTexture.active;RenderTexture.active=rt;var tex=new Texture2D(960,640,TextureFormat.RGB24,false);tex.ReadPixels(new Rect(0,0,960,640),0,0);tex.Apply();RenderTexture.active=previous;cam.targetTexture=null;
  if(name!=null)File.WriteAllBytes(Path.Combine(output,name+".png"),tex.EncodeToPNG());var pixels=tex.GetPixels();rt.Release();Object.DestroyImmediate(rt);Object.DestroyImmediate(tex);return pixels;
 }
}

