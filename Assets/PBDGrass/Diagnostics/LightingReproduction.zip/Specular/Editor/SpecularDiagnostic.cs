using System;
using System.IO;
using System.Reflection;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using GrassFinal.PBDGrass;
using Object=UnityEngine.Object;
public static class SpecularDiagnostic
{
 static GrassDemo demo;static Camera cam;static Material material;static string output;
 static string log="";static void Note(string text){log+=text+"\n";Debug.Log(text);}
 public static void Run()
 {
  output=Path.Combine(Path.GetTempPath(),"codex-grass-lighting/specular");Directory.CreateDirectory(output);
  try
  {
   EditorSceneManager.OpenScene("Assets/PBDGrass/Scenes/PBDGrassDemo.unity");demo=Object.FindObjectOfType<GrassDemo>();cam=demo.Cam;cam.enabled=false;cam.aspect=1.5f;
   foreach(var depth in Object.FindObjectsOfType<DepthTexMaker>())depth.enabled=false;
   foreach(var mesh in Object.FindObjectsOfType<MeshRenderer>())mesh.enabled=false;
   RenderSettings.fog=false;cam.clearFlags=CameraClearFlags.SolidColor;cam.backgroundColor=Color.black;QualitySettings.shadows=ShadowQuality.Disable;
   demo.Initialize();material=(Material)typeof(PBDGrassPatchRenderer).GetField("material",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(demo.Renderer);
   Note("COLORSPACE="+QualitySettings.activeColorSpace+" generated="+demo.Renderer.BladeCount);
   var normalBuffer=((System.Collections.Generic.List<ComputeBuffer>)typeof(PBDGrassPatchRenderer).GetField("buffers",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(demo.Renderer))[7];var before=new Vector3[normalBuffer.count];normalBuffer.GetData(before);
   Capture("normals-rest",1);Capture("roughness-default",2);Capture("specular-default",3);Capture("filter-default",4);
   material.SetFloat("_SpecularAA",0);Capture("specular-no-aa",3);Capture("roughness-no-aa",2);
   material.SetFloat("_Roughness",.28f);Capture("specular-smooth-no-aa",3);
   material.SetFloat("_Roughness",.48f);material.SetFloat("_SpecularAA",1);
   demo.Renderer.SetWind(new Vector3(10,0,3),.1f,new Vector4(.01f,.01f,0,1));for(int i=0;i<60;i++)demo.Renderer.Advance(1f/60);
   var after=new Vector3[normalBuffer.count];normalBuffer.GetData(after);double sum=0;float max=0;int changed=0;
   for(int i=0;i<before.Length;i++){float a=Vector3.Angle(before[i],after[i]);sum+=a;max=Mathf.Max(max,a);if(a>.01f)changed++;}
   Note("NORMAL_UPDATE vertices="+before.Length+" changed="+changed+" meanAngle="+(sum/before.Length)+" maxAngle="+max+" ticks="+demo.Renderer.SimulationTicks);
   Capture("normals-wind",1);Capture("specular-wind",3);
   var sun=Object.FindObjectsOfType<Light>().First(l=>l.type==LightType.Directional);sun.transform.rotation=Quaternion.Euler(10,155,0);Capture("specular-low-sun",3);
   Note("SPECULAR_DIAGNOSTIC_PASS");
  }
  catch(Exception e){Note(e.ToString());}
  finally{if(demo!=null)demo.enabled=false;File.WriteAllText(Path.Combine(output,"results.txt"),log);}
  if(!log.Contains("SPECULAR_DIAGNOSTIC_PASS")){EditorApplication.Exit(1);return;} LightingValidation.Run();
 }
 static void Capture(string name,float mode)
 {
  material.SetFloat("_LightingDebug",mode);
  var rt=new RenderTexture(960,640,24,RenderTextureFormat.ARGBFloat){antiAliasing=4};rt.Create();cam.targetTexture=rt;cam.Render();
  var previous=RenderTexture.active;RenderTexture.active=rt;var tex=new Texture2D(960,640,TextureFormat.RGBAFloat,false,true);tex.ReadPixels(new Rect(0,0,960,640),0,0);tex.Apply();RenderTexture.active=previous;cam.targetTexture=null;
  var pixels=tex.GetPixels();var values=pixels.Select(c=>(double)(c.r*.2126f+c.g*.7152f+c.b*.0722f)).Where(x=>x>1e-7).OrderBy(x=>x).ToArray();
  Note(name+" pixels="+values.Length+" mean="+(values.Length>0?values.Average():0)+" p95="+(values.Length>0?values[(int)(values.Length*.95)]:0)+" max="+(values.Length>0?values[values.Length-1]:0));
  var png=new Texture2D(960,640,TextureFormat.RGB24,false);png.SetPixels(pixels);png.Apply();File.WriteAllBytes(Path.Combine(output,name+".png"),png.EncodeToPNG());
  rt.Release();Object.DestroyImmediate(rt);Object.DestroyImmediate(tex);Object.DestroyImmediate(png);
 }
}


