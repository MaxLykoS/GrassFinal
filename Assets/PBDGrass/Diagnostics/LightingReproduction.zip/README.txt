Copy Assets/PBDGrass to a separate Unity 2022.3 project. For captures add Validation files at matching paths; run LightingValidation.Run in batchmode with Direct3D11.
For GPU measurements use the native timer/plugin from GPUPerformanceReproduction.zip and replace the matching profiling files with these. Run BuildGpuProfile.Run then the player with XPBD_GPU_PROFILE_OUTPUT set.
Profiling render targets are explicitly 1920x1080, HDR, MSAA4. Raw width/height fields report the OS window client area only. Phase 6 enables soft shadows/high resolution/two cascades/40m.
Do not apply profiling instrumentation or baseline files to the live project. GPU readback is asynchronous timestamp metadata only; editor capture fixture intentionally reads images/draw counts for assertions.
