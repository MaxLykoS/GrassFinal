Shader "Hidden/PBDGrass/LightingBaseline"
{
    Properties
    {
        [Header(Shading)]
        _TopColor("Top Color", Color) = (1,1,1,1)
        _BottomColor("Bottom Color", Color) = (1,1,1,1)
        _TranslucentGain("Translucent Gain", Range(0,1)) = 0.5

        [Header(Tessellation)]
        _TessellationUniform("Tessellation Uniform", Range(1, 64)) = 32

        [Header(BackLightSSS)]
        _InteriorColor("Interior Color", Color) = (1, 1, 1, 1)
        _BackSubsurfaceDistortion("Back Subsurface Distortion", Range(0, 1)) = 0.5
        _EdgeLitRate("Edge Light Rate", range(0, 2)) = 0.3
    }

        SubShader
    {
        Tags { "RenderType" = "Opaque" "IgnoreProjector" = "True" "LightMode" = "ForwardBase" }

        Cull Off

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 4.5

            #include "UnityCG.cginc"
            #include "Lighting.cginc"
            #define PI 3.14159

            StructuredBuffer<float3> VertexBuffer;
            StructuredBuffer<int> TriangleBuffer;
            StructuredBuffer<float3> NormalBuffer;
            StructuredBuffer<float2> UvBuffer;

            struct PBDGrid
            {
                float3 pos;
                int idOffset;
            };
            StructuredBuffer<PBDGrid> GridsVisibleBuffer;

            struct d2f
            {
                float4 pos : SV_POSITION;
                float2 uv : TEXCOORD0;
                float3 normalW : NORMAL;
                float3 viewDir : TEXCOORD1;
            };
            d2f vert(uint vertex_id : SV_VertexID, uint instance_id : SV_InstanceID)
            {
                d2f o;
                int index = TriangleBuffer[GridsVisibleBuffer[instance_id].idOffset * 39 + vertex_id];
                float3 world = VertexBuffer[index];
                o.pos = mul(UNITY_MATRIX_VP, float4(world, 1));
                o.uv = UvBuffer[index];
                o.normalW = normalize(NormalBuffer[index]);
                o.viewDir = normalize(_WorldSpaceCameraPos.xyz - world);
                return o;
            }

            float4 _TopColor;
            float4 _BottomColor;
            float _TranslucentGain;
            float _BackSubsurfaceDistortion;
            float _EdgeLitRate;
            float4 _InteriorColor;

            fixed4 frag(d2f o, fixed facing : VFACE) : SV_Target
            {
                o.normalW = normalize(o.normalW) * (facing > 0 ? 1 : -1);

                float3 lightDir = normalize(_WorldSpaceLightPos0);
                float4 texColor = lerp(_BottomColor, _TopColor, o.uv.y);
                float NdotL = saturate(saturate(dot(o.normalW, _WorldSpaceLightPos0)) + _TranslucentGain);

                // back light sss
                float3 backLitDir = o.normalW * _BackSubsurfaceDistortion + lightDir;
                float backSSS = saturate(dot(o.viewDir, -backLitDir));
                backSSS = saturate(pow(backSSS, 3));
                fixed3 edgeCol = backSSS * _EdgeLitRate * _InteriorColor * texColor.rgb;
                edgeCol += backSSS * _InteriorColor;

                float3 ambient = ShadeSH9(float4(o.normalW, 1));
                float4 lightIntensity = NdotL * _LightColor0 + float4(ambient, 1);
                float4 col = lerp(_BottomColor, _TopColor * lightIntensity, o.uv.y);
                return col + fixed4(edgeCol, 1);
            }
            ENDCG
        }
    }
}
