Measured on 2026-10-15, Unity 2022.3.62f2c1, RTX 3080 Ti, D3D11.
Use an isolated Unity project containing the current Assets/PBDGrass copy.
Extract GrassBirthEquilibriumProbe.cs to Assets/PBDGrass/Editor.
Run Unity with -batchmode -force-d3d11 -projectPath YOUR_TEST_PROJECT -executeMethod GrassFinal.PBDGrass.Editor.GrassBirthEquilibriumProbe.Run -logFile YOUR_LOG_PATH
The probe creates an empty scene and exits Unity; use the isolated test project only.
The output path is C:/Users/pc/AppData/Local/Temp/codex-grass-birth-equilibrium.json (edit for another machine).
passed means the probe completed, not that near/middle shape compatibility passed.
The runtime code and settings are unchanged from the handoff prototype recorded by HandoffSourceHashes.json.