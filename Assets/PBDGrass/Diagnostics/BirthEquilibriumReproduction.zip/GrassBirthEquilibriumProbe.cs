using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using Object=UnityEngine.Object;

namespace GrassFinal.PBDGrass.Editor
{
    public static class GrassBirthEquilibriumProbe
    {
        [Serializable] private sealed class Sample
        {
            public string load; public float seconds;
            public float nearMeanTipTravel, middleMeanTipTravel, meanTipGap, maxTipGap;
            public float nearMeanTipDrop, middleMeanTipDrop, nodeRmsGap, maxPlastic;
            public float physicalMeanTipTravel, physicalVsHandoffMeanTipGap;
        }
        [Serializable] private sealed class Report
        { public string gpu; public bool passed; public string error; public List<Sample> samples=new List<Sample>(); }
        private static Camera camera;
        private static ComputeShader solver,handoff;
        private static Material material;
        private static Texture2D wind;
        public static void Run()
        {
            var report=new Report { gpu=SystemInfo.graphicsDeviceName };
            try
            {
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
                camera=new GameObject("Birth probe camera").AddComponent<Camera>(); camera.enabled=false;
                solver=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/PBDGrass/Shaders/PBDSolverCS.compute");
                handoff=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/PBDGrass/Shaders/GrassHandoff.compute");
                material=AssetDatabase.LoadAssetAtPath<Material>("Assets/PBDGrass/Materials/PBDGrassProcedualMaterial.mat");
                wind=AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/PBDGrass/Textures/Wind.png");
                foreach(string load in new[] { "no_load","gravity","wind","gravity_wind" })
                {
                    var physics=new XPBDGrassSettings { MaxActiveBlades=32,NearDistance=1,PoolHysteresis=0,
                        Gravity=load.Contains("gravity")?new Vector3(0,-9.81f,0):Vector3.zero };
                    Vector3 force=load.Contains("wind")?new Vector3(10,0,3):Vector3.zero;
                    using(var near=Renderer(physics,true))using(var middle=Renderer(physics,true))using(var physical=Renderer(physics,false))
                    {
                        middle.SimulationCenter=new Vector3(100,0,100); middle.RefreshSimulationSelection();
                        foreach(var r in new[] { near,middle,physical })
                        { r.SetWind(force,.1f,new Vector4(.01f,.01f,0,1)); r.ResetDeformation(); }
                        var birthNear=near.Handoff.ReadDisplayNodes(); var birthMiddle=middle.Handoff.ReadDisplayNodes();
                        var birthPhysical=physical.ReadNodes();
                        Record(report,load,0,near,middle,physical,birthNear,birthMiddle,birthPhysical);
                        for(int tick=1;tick<=480;tick++)
                        {
                            near.Advance(1f/60); middle.Advance(1f/60); physical.Advance(1f/60);
                            if(tick==15 || tick==60 || tick==180 || tick==480)
                                Record(report,load,tick/60f,near,middle,physical,birthNear,birthMiddle,birthPhysical);
                        }
                        physics.Gravity=Vector3.zero;
                        foreach(var r in new[] { near,middle,physical })r.SetWind(Vector3.zero,.1f,new Vector4(.01f,.01f,0,1));
                        for(int tick=0;tick<360;tick++) { near.Advance(1f/60); middle.Advance(1f/60); physical.Advance(1f/60); }
                        Record(report,load+"_unloaded",14,near,middle,physical,birthNear,birthMiddle,birthPhysical);
                    }
                }
                report.passed=true;
            }
            catch(Exception e) { report.error=e.ToString(); Debug.LogError(e); }
            string output="C:/Users/pc/AppData/Local/Temp/codex-grass-birth-equilibrium.json";
            File.WriteAllText(output,JsonUtility.ToJson(report,true));
            Debug.Log("BIRTH_EQUILIBRIUM_"+(report.passed?"PASS":"FAIL")+" "+output);
            EditorApplication.Exit(report.passed?0:1);
        }
        private static PBDGrassPatchRenderer Renderer(XPBDGrassSettings physics,bool proxy)
        {
            var random=UnityEngine.Random.state; UnityEngine.Random.InitState(12345);
            var patch=new PBDGrassPatch(Vector3.zero,1,32,new GrassBladeShapeSettings()); UnityEngine.Random.state=random;
            try { return new PBDGrassPatchRenderer(patch,solver,material,camera,wind,physics,null,
                proxy?new GrassHandoffSettings():null,proxy?handoff:null); }
            finally { Object.DestroyImmediate(patch.PatchMesh); }
        }
        private static void Record(Report report,string load,float time,PBDGrassPatchRenderer near,PBDGrassPatchRenderer middle,
            PBDGrassPatchRenderer physical,BoneInfo[] birthNear,BoneInfo[] birthMiddle,BoneInfo[] birthPhysical)
        {
            var a=near.Handoff.ReadDisplayNodes(); var b=middle.Handoff.ReadDisplayNodes(); var c=physical.ReadNodes();
            var sample=new Sample { load=load,seconds=time };
            for(int i=0;i<a.Length;i++)
            {
                if(float.IsNaN(a[i].Position.sqrMagnitude) || float.IsInfinity(a[i].Position.sqrMagnitude))throw new Exception("Invalid node.");
                sample.nodeRmsGap+=(a[i].Position-b[i].Position).sqrMagnitude;
                if(i%8!=7)continue;
                sample.nearMeanTipTravel+=Vector3.Distance(a[i].Position,birthNear[i].Position)/32;
                sample.middleMeanTipTravel+=Vector3.Distance(b[i].Position,birthMiddle[i].Position)/32;
                float gap=Vector3.Distance(a[i].Position,b[i].Position);
                sample.meanTipGap+=gap/32; sample.maxTipGap=Mathf.Max(sample.maxTipGap,gap);
                sample.nearMeanTipDrop+=(birthNear[i].Position.y-a[i].Position.y)/32;
                sample.middleMeanTipDrop+=(birthMiddle[i].Position.y-b[i].Position.y)/32;
                sample.physicalMeanTipTravel+=Vector3.Distance(c[i].Position,birthPhysical[i].Position)/32;
                sample.physicalVsHandoffMeanTipGap+=Vector3.Distance(c[i].Position,a[i].Position)/32;
            }
            sample.nodeRmsGap=Mathf.Sqrt(sample.nodeRmsGap/a.Length);
            foreach(var p in near.ReadPlasticBends())sample.maxPlastic=Mathf.Max(sample.maxPlastic,p.magnitude);
            report.samples.Add(sample);
        }
    }
}
